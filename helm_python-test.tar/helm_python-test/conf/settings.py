from kubernetes import client, config

#path to kubernetes config file
config.load_kube_config("/home/centos/helm_python/conf/kube_file.conf")
#variable for set up kubernetes API
v1 = client.CoreV1Api()
#variable for load command templates
comander="/home/centos/helm_python/operation/command_lists.txt"
#variable for load file with operations and variables
input_operation="/home/centos/helm_python/input.yaml"
#variable for create json_file
input_operation_json="/home/centos/helm_python/conf/input.json"
#variable for load file with good health of kubernetes cluster
help_health_compare="/home/centos/helm_python/conf/health_good.txt"
#variable for insert log to file
log_file="/home/centos/helm_python/logs/app.log"
#command for create pv
command_volume='/home/centos/helm_python/operation/command_volume.txt'
#yaml for create folder on worker node
help_pod='/home/centos/helm_python/operation/help_pod.yaml'
