import logging
from datetime import datetime
from conf import settings

                #delete_CNF(commands,NAMESPACE,NAME_HELM_DEP,wait_health,uider)

#set up logging for 4 type of errors
def loger(typo,text,uider):
    one_log=text + ' ' + '[' +str(uider) + ']'
    if typo == 'deb':
        logging.basicConfig(filename=settings.log_file,filemode='a', format='%(asctime)s.%(msecs)03d %(levelname)s - %(message)s',datefmt='%d-%b-%y %H:%M:%S',level=logging.DEBUG)
        return logging.debug(one_log)
    elif typo == 'err':
        logging.basicConfig(filename=settings.log_file,filemode='a', format='%(asctime)s.%(msecs)03d %(levelname)s - %(message)s',datefmt='%d-%b-%y %H:%M:%S',level=logging.ERROR)
        return logging.error(one_log)
    elif typo == 'inf':
        logging.basicConfig(filename=settings.log_file,filemode='a', format='%(asctime)s.%(msecs)03d %(levelname)s - %(message)s',datefmt='%d-%b-%y %H:%M:%S',level=logging.INFO)
        return logging.info(one_log)
    elif typo == 'war':
        logging.basicConfig(filename=settings.log_file,filemode='a', format='%(asctime)s.%(msecs)03d %(levelname)s - %(message)s',datefmt='%d-%b-%y %H:%M:%S',level=logging.WARNING)
        return logging.warning(one_log)
    elif typo == 'cri':
        logging.basicConfig(filename=settings.log_file,filemode='a', format='%(asctime)s.%(msecs)03d %(levelname)s - %(message)s',datefmt='%d-%b-%y %H:%M:%S',level=logging.CRITICAL)
        return logging.critical(one_log)

def loger_screen(text):
      time=datetime.utcnow().strftime('%H:%M:%S.%f')[:-3]
      together=time+ ' ' + ' ' + text
      return print(together) 
    

  

