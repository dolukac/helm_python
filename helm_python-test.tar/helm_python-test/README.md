# CNF exercise in Python and Helm

* Instantiate any CNF
    * Input for instantiation is CNF name, namespace to be used, Helm Chart URL, values.yaml file URL
    * After instantiation of a CNF, health check is needed
* Update config of any CNF
    *  input of config update can be either values.yaml file or only single or couple of parameters of the values.yaml file and the CNF name/ID
    *  Before update or upgrade or terminate a CNF, health check is needed.
    *  After update and upgrade of a CNF, health check is needed
* Upgrade of any CNF with auto rollback option
    * Input for upgrade is a URL for new Helm chart version and CNF name/ID
    * After update and upgrade of a CNF, health check is needed
* Health check of CNF
* Terminate CNF
    * input for terminate is CNF name/ID

**That is required to be executed using Helm and using Flux**

## Additional info
* Kubernetes cluster **10.50.0.48**
* **home/centos/helm_python** repo
* Script can be executed via **python3 main.py**
* Required versions:
    * Python 3.6.8
    * Kubernetes 1.24.2
    * Helm 3.8.2
    * CNFs https://github.com/dolukac/towards5gs-helm


## Solution

* How to implement helm operations in python script:
    *   For helm 3.8.2 (version helm in lab) doesn’t work python library pyhelm (https://pypi.org/project/pyhelm/ , library is for helm with version < 3, because in version lower than 3 is Tiller)
    *   So other option for work with helm helm is use os library https://docs.python.org/3/library/os.html and subprocess https://docs.python.org/3/library/subprocess.html  , so in basic writting commands from CLI directly to Python script. 


### Structure

```
├── conf > Directory for configuration
│   ├── health_good.txt > File with stored good state of cluster
│   ├── input.json > Converted input yaml to json
│   ├── kube_file.conf > Configuration file for Kubernetes cluster
│   ├── log.py > Set-up logging
│   ├── logging_text.py > Most used log messages
│   └── settings.py > Paths to necessary files and global variable
├── input.yaml > Input file with specific variables for operations
├── logs
│   └── app.log > Log file
├── main.py > Main logic of solution
├── operation
│   ├── checker.py > Verify conditions for operations
│   ├── cleaner.py > Delete CNF/Delete CNF/Log cleaner
│   ├── command_lists.txt > Template list of helm/k8s commands
│   ├── commands.py > Function for execute command
│   ├── command_volume.txt > teplate for create PV
│   ├── create_namespace_CNF.py > Create CNF/Create namespace
│   ├── help_pod.yaml > teplate for temporary pod
│   └── update_upgrade_CNF.py > Update/Upgrade CNF
└── README.md > Documentation
```

* file kube_file.conf is missing from gitlab repo (security reasons)

### Logging

#### Log file

All operations insert logs into log/app.log . With date, time, level of logging (INFO-good result of something,ERROR-error result of something,WARNING-what can be wrong,DEBUG-just pure information), relevant text, UUID. UUID collect same operations via equal value. Example of log file:

```
25-Jul-22 13:35:57.545 DEBUG -  [-----------Start of the execution----------]
25-Jul-22 13:35:57.545 DEBUG - Working on cluster health check [b0621f07-968c-422d-80b6-cd0f603bf210]
25-Jul-22 13:35:57.603 INFO - Cluster is in good health [b0621f07-968c-422d-80b6-cd0f603bf210]
25-Jul-22 13:35:57.603 DEBUG - Input parameters:operation:delete CNF ,namespace:free5gc-cp ,cnf_name:nrf ,timer:10  [b0621f07-968c-422d-80b6-cd0f603bf210]
25-Jul-22 13:35:57.604 DEBUG - Working on deletion of CNF [b0621f07-968c-422d-80b6-cd0f603bf210]
25-Jul-22 13:36:10.277 INFO - CNF nrf in namespace free5gc-cp  deleted. [b0621f07-968c-422d-80b6-cd0f603bf210]
25-Jul-22 13:36:10.278 DEBUG -  [-----------End of the execution----------]
```

### CLI prompt
Basic informations (milestones) as input file, result of health check and so on. Example of output from CLI prompt:
```
13:48:46.294  Input for operation as json: 
{
    "operation": "delete CNF",
    "namespace": "free5gc-cp",
    "cnf_name": "nrf",
    "timer": 10
}
13:48:46.339  CNF already deleted. No further actions needed
```

### Input file

Represents input.yaml, where are each operation is in separated list. Key operation with value in list represents name of operations with specific value (name of operation) and based on this value (name of operation) script know which operation needs to be triggered. Rest keys:values represent parameters for operations. Operation in script are in the list below (each operation will be described later with real example):

* yaml/python_script/in helm or kubernetes
* **create namespace/create_namespace=** creation namespace in cluster
* **delete namespace/delete_namespace=** delete namespace from cluster
* **instanciate CNF/instanciate_CNF=** helm release install
* **update via CLI/update_via_CLI=** helm release upgrade via CLI ("-- set XX.XX=YY")
* **update via yaml/update_via_YAML=** helm release upgrade via YAML (change in yaml and then update release)
* **update chart/upgrade_chart_version=** helm release upgrade chart version
* **rollback CNF/rollback_cnf=** helm release rollback (!!! helm 3 default value max 10 version return !!!)
* **delete CNF/delete_CNF=** helm release uninstall/deletion 


For each operations apply logic like before update_via_YAML needs to be instanciate_CNF if no then error(failure). Each operation include cluster health check so if cluster isn't in good health then script stop execute itself. Some operations include health check of CNF (for this scenario check if is pod running) or some other verification. Each operation create loging into log file . If name of the operation doesn't exist then add error to log file. If needed keys for specific operation doesn't exist or some value is missing then also add error to log file. If is special pameter autorollback for some operation missing or not equal (True/False) also add error log to log file. Function which process input file is main function (described below).

**Example of input file (input.yaml):**

```
- operation: create namespace
  namespace: test2

- operation: delete namespace
  namespace: test2
  timer: 5

- operation: instanciate CNF
  namespace: free5gc-cp
  cnf_name: nrf
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 1
  autorollback: True
```


### CNF operations and functions

### 0. Main function

#### 0.1. Function definition

**Short description:**
1. Input file (input.yaml) is load.
2. Convert input taml file to input.json.
3. Load json file as list.
4. Load each element of list separately (each element is list).
5. Generate UUID for identification of specific operation.
6. Create cluster_health_check if is cluster in good health for perfom some operations.
7. Check if is value in key operation equal some operation. If no add error log if yes then continue.
8. Add log informations.
9. Check if keys for specific operations equal this specific operation. If no add error log if yes then continue.
10. Check if values for keys for specific operation aren't empty. If yes add error log if no then continue.
11. Add keys from values to specific parameters for operation.
12. Perform operation.


#### 0.2. Function example

**0.2.1. Relevant operation**

**Scenario:** Execute script in input.yaml with some relevant operation

**Input file:**
```
- operation: create namespace
  namespace: test
```

**CLI output:**

```
13:54:01.218  Input for operation as json: 
{
    "operation": "create namespace",
    "namespace": "test"
}

13:54:04.256  Namespace created
13:54:04.538  Persistent volume created
```


**Log file:**
```
25-Jul-22 13:54:01.153 DEBUG -  [-----------Start of the execution----------]
25-Jul-22 13:54:01.153 DEBUG - Working on cluster health check [1108ac27-6a6a-4737-bc80-60d9f33fdd36]
25-Jul-22 13:54:01.218 INFO - Cluster is in good health [1108ac27-6a6a-4737-bc80-60d9f33fdd36]
25-Jul-22 13:54:01.218 DEBUG - Input parameters:operation:create namespace ,namespace:test  [1108ac27-6a6a-4737-bc80-60d9f33fdd36]
25-Jul-22 13:54:01.218 DEBUG - Working on namespace creation [1108ac27-6a6a-4737-bc80-60d9f33fdd36]
25-Jul-22 13:54:04.255 INFO - Namespace test created [1108ac27-6a6a-4737-bc80-60d9f33fdd36]
25-Jul-22 13:54:04.538 INFO - persistentvolume/helmpython546447 created  [1108ac27-6a6a-4737-bc80-60d9f33fdd36]
25-Jul-22 13:54:04.538 DEBUG -  [-----------End of the execution----------]
```

**Result:** Script perfom relevant operation.

**0.2.2. Wrong name of operation**

**Scenario:** Execute script in input.yaml with some wrong operation name. 

**Input file:**
```
- operation: create
  namespace: test
```

**CLI output:**
```
13:56:06.365  Input for operation as json: 
{
    "operation": "create",
    "namespace": "test"
}
13:56:06.365  ERROR Input parameters do not met condidion for any operation. Please check operation name or values
```

**Log file:**
```
25-Jul-22 13:56:06.309 DEBUG - Working on cluster health check [a057b6e8-c205-4487-8a9d-c659513a39a1]
25-Jul-22 13:56:06.365 INFO - Cluster is in good health [a057b6e8-c205-4487-8a9d-c659513a39a1]
25-Jul-22 13:56:06.365 DEBUG - Input parameters:operation:create ,namespace:test  [a057b6e8-c205-4487-8a9d-c659513a39a1]
25-Jul-22 13:56:06.365 ERROR - Input parameters do not met condidion for any operation. Please check operation name or values [a057b6e8-c205-4487-8a9d-c659513a39a1]
```

**Result:**  Script add error log to log file.

**0.2.3. Relevant operation**

**Scenario:** Execute script in input.yaml with relevant operation name, but without some value for needed key. 

**Input file:**
```
- operation: update via CLI
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  timer: 10
  autorollback: 
  set: [global.sbi.scheme=https]
```

**CLI output:**
```
09:08:33.095  Input for operation as json: 
{
    "operation": "update via CLI",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "timer": 10,
    "autorollback": null,
    "set": [
        "global.sbi.scheme=https"
    ]
}
09:08:33.096  Error input parameters for update via CLI do not met condition for update CLI via script. Please check input parameters
```

**Log file:**
```
26-Jul-22 09:08:33.025 DEBUG - Working on cluster health check [8a4abac6-6761-4b7e-93f8-d712d9dbc62e]
26-Jul-22 09:08:33.095 INFO - Cluster is in good health [8a4abac6-6761-4b7e-93f8-d712d9dbc62e]
26-Jul-22 09:08:33.096 DEBUG - Input parameters:operation:update via CLI ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,timer:10 ,autorollback:None ,set:['global.sbi.scheme=https']  [8a4abac6-6761-4b7e-93f8-d712d9dbc62e]
26-Jul-22 09:08:33.096 DEBUG - Working update via CLI [8a4abac6-6761-4b7e-93f8-d712d9dbc62e]
26-Jul-22 09:08:33.096 ERROR - Input parameters for update via CLI do not met condition for update CLI via script. Please check input parameters [8a4abac6-6761-4b7e-93f8-d712d9dbc62e]
```

**Result:** Script add error log to log file.


**0.2.4. Relevant operation with missing needed key,value**

**Scenario:** Execute script in input.yaml with relevant operation name, but without key,value needed for operation. 

**Input file:**
```
-operation: create namespace
```

**CLI output:**
```
14:00:29.243  Input for operation as json: 
{
    "operation": "create namespace"
}
14:00:29.244  ERROR Input parameters do not met condidion for any operation. Please check operation name or values
```

**Log file:**
```
25-Jul-22 14:00:29.184 DEBUG - Working on cluster health check [5829bc44-31b6-447e-aebe-d4a3301bc654]
25-Jul-22 14:00:29.243 INFO - Cluster is in good health [5829bc44-31b6-447e-aebe-d4a3301bc654]
25-Jul-22 14:00:29.243 DEBUG - Input parameters:operation:create namespace  [5829bc44-31b6-447e-aebe-d4a3301bc654]
25-Jul-22 14:00:29.243 ERROR - Input parameters do not met condidion for any operation. Please check operation name or values [5829bc44-31b6-447e-aebe-d4a3301bc654]
```

**Result:** Script add error log to log file.



### 1. Cluster health check (function)

#### 1.1. Function definition

```
cluster_health_check(commands[0],uider)
```

**Parameters:**
* **commands[0]**=load commands from commands_list (kubectl get --raw=/readyz?verbose)
* **uider**=uuid identificator (generated in main.py)

**Short description:**

Check if is state of cluster is in good health via **kubectl get --raw=/readyz?verbose**. Via comparing good health of cluster with actual state of cluster. If they are same then do nothing just add information to log file, if they are different then stop script and redirect output to log file. This cluster_health_check is implemented for each operation.

#### 1.2. Function example


**1.2.1. Good state of cluster**

**Scenario:** Execute script with some operation in input.yaml. 

**Input file:**
```
-operation: create namespace
```



**Log file:**
```
25-Jul-22 14:00:29.184 DEBUG -  [-----------Start of the execution----------]
25-Jul-22 14:00:29.184 DEBUG - Working on cluster health check [5829bc44-31b6-447e-aebe-d4a3301bc654]
25-Jul-22 14:00:29.243 INFO - Cluster is in good health [5829bc44-31b6-447e-aebe-d4a3301bc654]
---
```

**Result:** Script continued in perfom operation.

**1.2.2. Bad state of cluster**

**Scenario:** Execute script with some operation in input.yaml with some change in health_good.txt (good state of cluster).  

**Input file:**
```
-operation: create namespace
```


**Log file:**
```
25-Jul-22 14:03:30.336 DEBUG - Working on cluster health check [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.391 ERROR - Cluster is not in good health [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]ping ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]log ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]etcd ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]informer-sync ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/start-kube-apiserver-admission-initializer ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/generic-apiserver-start-informers ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/priority-and-fairness-config-consumer ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/priority-and-fairness-filter ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/start-apiextensions-informers ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/start-apiextensions-controllers ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/crd-informer-synced ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/bootstrap-controller ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/rbac/bootstrap-roles ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/scheduling/bootstrap-system-priority-classes ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/priority-and-fairness-config-producer ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/start-cluster-authentication-info-controller ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/aggregator-reload-proxy-client-cert ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/start-kube-aggregator-informers ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/apiservice-registration-controller ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/apiservice-status-available-controller ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.392 WARNING - [+]poststarthook/kube-apiserver-autoregistration ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.393 WARNING - [+]autoregister-completion ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.393 WARNING - [+]poststarthook/apiservice-openapi-controller ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.393 WARNING - [+]shutdown ok [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
25-Jul-22 14:03:30.393 WARNING - readyz check passed [bb2276b6-7a00-4c41-a9c3-da42d4168cc8]
```

**Result:** Scipt stop perform any actions, actual state of cluster is add to log file with warning message.

### 2 Health check of CNF (check if are pods running) (function)

```
def pod_health_check(NAMESPACE,NAME_HELM_DEP,wait_health,uider)
```

**Parameters:**
* **NAMESPACE**=namespace name
* **NAME_HELM_DEP**=CNF name (helm release name)
* **wait_health**=sleep time in seconds for health check
* **uider**=uuid identificator (generated in main.py)

**Short description:**

Check if is/are pod/pods running via 3 iteration. In iteration is firstly sleep time (timer=wait_health) for some delay (it doesn't make a sense to do it without delay, because right after some operation this operation doesn't have immediate impact). After sleep is created list of pods in namespace. Then is checked status and name of these pods. If is status active and name of pods start with letters of helm release then is health check of pods right and information is added to log file a if no then continue in iterating until ending of third iteration. If is result after third iteration still not good health of pods. Then health is not good and error log is added to log file. This function is implemented after instanciate_CNF and before and after update_via_cli,update_via_yaml,upgrade_chart_version and rollback_revision_CNF. Example of logging will be shown in relevant functions/operations.


### 3 Create namespace (operation)

#### 3.1. Function definition
```
 def create_namespace(commands,NAMESPACE,wait_health,uider)
```

**Parameters:**
* **NAMESPACE**=namespace name
* **wait_health**=sleep time after creation of file in node
* **uider**=uuid identificator (generate in main.py)

**Short description:**
Check if namespace exists, if no exist then create together with persistent volume and directory in node. Check 3 times(iterate) if is created. If isn't created after 3 iteration add error log. If is created in iteration then add info log and create persistent volume. If is persistentvolume created add info log if no add error log.  After each iteration wait/sleep (sleep time in sec=wait_health).

#### 3.2. Function example

#### 3.2.1. Creation of namespace which doesn’t exist

**Scenario:** Execute script with create_namespace operation in input.yaml with name of namespace which not exist. 

**Input file:**
```
- operation: create namespace
  timer: 10
  namespace: gitlabtest
```

**CLI output:**
```
[centos@k8master helm_python]$ python3 main.py 
15:00:03.525  Input for operation as json: 
{
    "operation": "create namespace",
    "timer": 10,
    "namespace": "gitlabtest"
}
15:00:06.561  Namespace created
15:00:18.125  Directory helmpython110890 for persistent volume created in k8worker4
15:00:18.330  Persistent volume created
```

**Log file:**
```
27-Jul-22 15:00:03.467 DEBUG - Working on cluster health check [6353eed1-8ab0-4893-aa10-27d877601f69]
27-Jul-22 15:00:03.525 INFO - Cluster is in good health [6353eed1-8ab0-4893-aa10-27d877601f69]
27-Jul-22 15:00:03.525 DEBUG - Input parameters:operation:create namespace ,timer:10 ,namespace:gitlabtest  [6353eed1-8ab0-4893-aa10-27d877601f69]
27-Jul-22 15:00:03.525 DEBUG - Working on namespace creation [6353eed1-8ab0-4893-aa10-27d877601f69]
27-Jul-22 15:00:06.561 INFO - Namespace gitlabtest created [6353eed1-8ab0-4893-aa10-27d877601f69]
27-Jul-22 15:00:18.124 INFO - Directory helmpython110890 for persistent volume created in k8worker4 [6353eed1-8ab0-4893-aa10-27d877601f69]
27-Jul-22 15:00:18.330 INFO - persistentvolume/helmpython110890 created  [6353eed1-8ab0-4893-aa10-27d877601f69]
```

**Result:** Script created namespace. 




#### 3.2.2. Creation of namespace which exist

**Scenario:**  Execute script with create_namespace operation in input.yaml with name of namespace which exist.  

**Input file:**
```
- operation: create namespace
  timer: 10
  namespace: gitlabtest
```

**CLI output:**
```
15:00:28.712  Input for operation as json: 
{
    "operation": "create namespace",
    "timer": 10,
    "namespace": "gitlabtest"
}
15:00:28.732  Namespace already exist
```

**Log file:**
```
27-Jul-22 15:00:28.654 DEBUG - Working on cluster health check [7551fa94-0875-4601-924b-9fc28983ce21]
27-Jul-22 15:00:28.712 INFO - Cluster is in good health [7551fa94-0875-4601-924b-9fc28983ce21]
27-Jul-22 15:00:28.712 DEBUG - Input parameters:operation:create namespace ,timer:10 ,namespace:gitlabtest  [7551fa94-0875-4601-924b-9fc28983ce21]
27-Jul-22 15:00:28.712 DEBUG - Working on namespace creation [7551fa94-0875-4601-924b-9fc28983ce21]
27-Jul-22 15:00:28.732 INFO - Namespace gitlabtest already exist [7551fa94-0875-4601-924b-9fc28983ce21]
```

**Result:** Namespace test can not be created beceause already exist.


### 4 Delete namespace (operation)

#### 4.1. Function definition

```
def delete_namespace(NAMESPACE,wait_health,uider)
```

**Parameters:**
* **NAMESPACE**=namespace name
* **wait_health**=timer,sleep time for check if is namespace deleted
* **uider**=uuid identificator (generated in main.py)

**Short description:**
Check if namespace exist, if yes then delete. Check 3 times(iterate) if is deleted. If is deleted in iteration then add info log and stop iterate. If isn't deleted after 3 iteration add error log. After each iteration wait/sleep (sleep time in sec=timer=wait_health).

#### 4.2. Function example


#### 4.2.1. Deletion of namespace which exist 

**Scenario:** Execute script with delete_namespace operation with same namespace as in previos case in input.yaml. 

**Input file:**
```
- operation: delete namespace 
  namespace: new
  timer: 3
```

**CLI output:**
```
14:16:23.954  Input for operation as json: 
{
    "operation": "delete namespace",
    "namespace": "new",
    "timer": 3
}
14:16:23.972  Namespace doesn't exist
```

**Log file:**
```
25-Jul-22 14:16:23.896 DEBUG - Working on cluster health check [ac686241-4033-4098-a986-1ddc4655d535]
25-Jul-22 14:16:23.953 INFO - Cluster is in good health [ac686241-4033-4098-a986-1ddc4655d535]
25-Jul-22 14:16:23.954 DEBUG - Input parameters:operation:delete namespace ,namespace:new ,timer:3  [ac686241-4033-4098-a986-1ddc4655d535]
25-Jul-22 14:16:23.954 DEBUG - Working on namespace deletion [ac686241-4033-4098-a986-1ddc4655d535]
25-Jul-22 14:16:23.972 ERROR - Namespace new does not exist [ac686241-4033-4098-a986-1ddc4655d535]
```

**Result:** Namespace can not be delete beceause doesn't exist.


#### 4.2.2.  Deletion of namespace which not exist

**Scenario:** Execute script with delete_namespace operation with same namespace as in previos case in input.yaml. 

**Input file:**
```
- operation: delete namespace 
  namespace: new
  timer: 3
```

**CLI output:**
```
14:14:54.981  Input for operation as json: 
{
    "operation": "delete namespace",
    "namespace": "new",
    "timer": 3
}
14:15:01.046  Namespace deleted
```

**Log file:**
```
25-Jul-22 14:14:54.922 DEBUG - Working on cluster health check [702fe0a6-8d2e-416f-9504-1985c7aec9f4]
25-Jul-22 14:14:54.981 INFO - Cluster is in good health [702fe0a6-8d2e-416f-9504-1985c7aec9f4]
25-Jul-22 14:14:54.981 DEBUG - Input parameters:operation:delete namespace ,namespace:new ,timer:3  [702fe0a6-8d2e-416f-9504-1985c7aec9f4]
25-Jul-22 14:14:54.981 DEBUG - Working on namespace deletion [702fe0a6-8d2e-416f-9504-1985c7aec9f4]
25-Jul-22 14:15:01.046 INFO - Namespace new deleted [702fe0a6-8d2e-416f-9504-1985c7aec9f4]
```

**Result:** Scipt deleted namespace new. 

### 5 Instantiation of CNF (helm release install) (operation)

#### 5.1. Function definition

```
def instanciate_CNF(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL, CHART_VALUES_URL,wait_health,auto,uider)
```

**Parameters:**

* **commands**=load commands from commands_list as template (helm -n {NAMESPACE} install {NAME_HELM_DEP} {CHART_NAME_URL} -f {CHART_VALUES_URL})
* **NAMESPACE**=namespace name
* **NAME_HELM_DEP**=CNF name (helm release name)
* **CHART_NAME_URL**=url for chart
* **CHART_VALUES_URL**=url for value.yaml
* **wait_health**=timer,sleep time for health check of pod or deletion
* **auto**=deletion after not good state of helmrelease pods (True/False)
* **uider**=uuid identificator (generated in main.py)

**Short description:**

1. Replace value in template > create CLI helm comand.
2. Check if is namespace active (THIS function is implemented just here, but can be implemented anywhere).
3. If is namespace active then perform operation in this case create CNF (helm release install).
4. If is operation without error then  continue on 5. If is with error print error message.
5. Health check of pod (Check if is  release in good health via checking pod. If yes then add info to log gile, if no then add error to log file and continue to 6).
6. Check if is auto equal False. If yes add error to log file. If no delete CNF via function def delete_CNF.

#### 5.2. Function example

#### 5.2.1. Instantiation of CNF with relevant parameters

**Scenario:** Execute script with operation instanciate_CNF in input.yaml with relevant parameters.  

**Input file:**
```
- operation: instanciate CNF
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 90
  autorollback: False
```

**CLI output:**
```
14:22:55.689  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
14:22:55.709  Namespace is active
14:25:57.701  Health check is good
```

**Log file:**
```
25-Jul-22 14:22:55.624 DEBUG - Working on cluster health check [cee1f510-6818-4246-b6c1-92f5ec6e6736]
25-Jul-22 14:22:55.689 INFO - Cluster is in good health [cee1f510-6818-4246-b6c1-92f5ec6e6736]
25-Jul-22 14:22:55.689 DEBUG - Input parameters:operation:instanciate CNF ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [cee1f510-6818-4246-b6c1-92f5ec6e6736]
25-Jul-22 14:22:55.689 DEBUG - Working on instanciation of CNF [cee1f510-6818-4246-b6c1-92f5ec6e6736]
25-Jul-22 14:22:55.709 INFO - Namespace nrf is active [cee1f510-6818-4246-b6c1-92f5ec6e6736]
25-Jul-22 14:22:55.709 DEBUG - Implemantation of command: helm -n nrf install nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [cee1f510-6818-4246-b6c1-92f5ec6e6736]
25-Jul-22 14:25:57.701 INFO - Health check is good [cee1f510-6818-4246-b6c1-92f5ec6e6736]
```

**Result:** Instanciation of CNF (helm release install) was good. Health check after operation also good. Check CLI prompt of running pods below.

```
[centos@k8master helm_python]$ kubectl get pods -n nrf
NAME                                       READY   STATUS    RESTARTS   AGE
mongodb-0                                  1/1     Running   0          3m11s
nrftest-free5gc-nrf-nrf-6d9c4fd865-pkxgs   1/1     Running   0          3m11s
```

#### 5.2.2. Instantiation of CNF with relevant parameters, but with short wait_health and autorollback equal False

**Scenario:** Execute script with operation instanciate_CNF in input.yaml with relevant parameters, but timer(wait time) for health check just 5 second instead of 90 as in previous case and with autorollback equal False.  

**Input file:**
```
- operation: instanciate CNF
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 1
  autorollback: False
```

**CLI output:**
```
14:29:08.194  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 1,
    "autorollback": false
}
14:29:08.214  Namespace is active
14:29:13.419  Error Health check is not good. Rollback is set to: False
14:29:13.419  Please check status of pods
```

**Log file:**
```
25-Jul-22 14:29:08.133 DEBUG - Working on cluster health check [c9f2055b-acb5-4617-8088-003cf961d594]
25-Jul-22 14:29:08.194 INFO - Cluster is in good health [c9f2055b-acb5-4617-8088-003cf961d594]
25-Jul-22 14:29:08.194 DEBUG - Input parameters:operation:instanciate CNF ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:1 ,autorollback:False  [c9f2055b-acb5-4617-8088-003cf961d594]
25-Jul-22 14:29:08.194 DEBUG - Working on instanciation of CNF [c9f2055b-acb5-4617-8088-003cf961d594]
25-Jul-22 14:29:08.214 INFO - Namespace nrf is active [c9f2055b-acb5-4617-8088-003cf961d594]
25-Jul-22 14:29:08.214 DEBUG - Implemantation of command: helm -n nrf install nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [c9f2055b-acb5-4617-8088-003cf961d594]
25-Jul-22 14:29:13.418 ERROR - Health check is not good [c9f2055b-acb5-4617-8088-003cf961d594]
25-Jul-22 14:29:13.419 INFO - Rollback in case of failure is set to False [c9f2055b-acb5-4617-8088-003cf961d594]
25-Jul-22 14:29:13.419 WARNING - Please check status of pods [c9f2055b-acb5-4617-8088-003cf961d594]
```

**Result:** Instanciation of CNF (helm release install) was good. Health check after operation was wrong because pod were in init status, autorollback was set to false (no deletion of CNF). Check output from CLI prompt of (running pods) below.

```
[centos@k8master helm_python]$ kubectl get pods -n nrf
NAME                                       READY   STATUS     RESTARTS   AGE
mongodb-0                                  0/1     Running    0          11s
nrftest-free5gc-nrf-nrf-6d9c4fd865-nwpb8   0/1     Init:0/1   0          11s
```

#### 5.2.3.Instantiation of CNF with relevant parameters, but with short wait_health and autorollback equal True

**Scenario:**  Execute script with operation instanciate_CNF in input.yaml with relevant parameters, but wait time for health check just 10 second  and with autorollback equal True. 

**Input file:**
```
- operation: instanciate CNF
  namespace: space
  cnf_name: nrf
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 1
  autorollback: True
```

**CLI output:**
```
13:31:21.109  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "space",
    "cnf_name": "nrf",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 1,
    "autorollback": true
}
13:31:21.130  Namespace is active
13:31:21.130  Operation is executing
13:31:22.857  Operation is executed
13:31:26.912  Error Health check is not good. Rollback is set to: True
13:31:26.981  Status of pods before deletion mongodb-0 Running,nrf-free5gc-nrf-nrf-7ff8dcbb5d-6bnxz Init:0/1
13:31:28.510  Status of pods changed mongodb-0 Terminating,nrf-free5gc-nrf-nrf-7ff8dcbb5d-6bnxz Terminating
13:31:33.863  Status of pods changed nrf-free5gc-nrf-nrf-7ff8dcbb5d-6bnxz Terminating
13:32:03.796  CNF deleted
```

**Log file:**
```
01-Aug-22 13:31:21.044 DEBUG - Working on cluster health check [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:21.108 INFO - Cluster is in good health [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:21.109 DEBUG - Input parameters:operation:instanciate CNF ,namespace:space ,cnf_name:nrf ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:1 ,autorollback:True  [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:21.109 DEBUG - Working on instanciation of CNF [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:21.130 INFO - Namespace space is active [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:21.130 DEBUG - Implemantation of command: helm -n space install nrf https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:26.912 ERROR - Health check is not good [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:26.912 INFO - Rollback in case of failure is set to True [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:26.912 DEBUG - Working on rollback (deletion of CNF) [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:26.981 DEBUG - Status of pods before deletion mongodb-0 Running,nrf-free5gc-nrf-nrf-7ff8dcbb5d-6bnxz Init:0/1 [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:28.509 INFO - Status of pods changed mongodb-0 Terminating,nrf-free5gc-nrf-nrf-7ff8dcbb5d-6bnxz Terminating [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:31:33.862 INFO - Status of pods changed nrf-free5gc-nrf-nrf-7ff8dcbb5d-6bnxz Terminating [c4d4b197-9263-47ba-bd20-be291722820c]
01-Aug-22 13:32:03.796 INFO - CNF nrf in namespace space  deleted. [c4d4b197-9263-47ba-bd20-be291722820c]
```

**Result:** Instanciation of CNF (helm release install) was good. Health check after operation was wrong because pod were in init status, autorollback was set to true ( deletion of CNF). CNF is deleted


#### 5.2.4. Instantiation of CNF with relevant parameters, but with helm release which already exist

**Scenario:** Execute script with operation instanciate_CNF in input.yaml with same relevant parameters twice.  

**Input file:**
```
- operation: instanciate CNF
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 90
  autorollback: False
```

**CLI output:**
```
14:35:02.366  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
14:35:02.386  Namespace is active
14:35:03.049  Error: INSTALLATION FAILED: cannot re-use a name that is still in use
```

**Log file:**
```
25-Jul-22 14:35:02.296 DEBUG -  [-----------Start of the execution----------]
25-Jul-22 14:35:02.296 DEBUG - Working on cluster health check [be987f74-3411-4214-91df-e79254598a39]
25-Jul-22 14:35:02.366 INFO - Cluster is in good health [be987f74-3411-4214-91df-e79254598a39]
25-Jul-22 14:35:02.366 DEBUG - Input parameters:operation:instanciate CNF ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [be987f74-3411-4214-91df-e79254598a39]
25-Jul-22 14:35:02.367 DEBUG - Working on instanciation of CNF [be987f74-3411-4214-91df-e79254598a39]
25-Jul-22 14:35:02.386 INFO - Namespace nrf is active [be987f74-3411-4214-91df-e79254598a39]
25-Jul-22 14:35:02.386 DEBUG - Implemantation of command: helm -n nrf install nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [be987f74-3411-4214-91df-e79254598a39]
25-Jul-22 14:35:03.049 ERROR - Implemantation of command: Error: INSTALLATION FAILED: cannot re-use a name that is still in use [be987f74-3411-4214-91df-e79254598a39]
25-Jul-22 14:35:03.049 WARNING - Please check input parameters [be987f74-3411-4214-91df-e79254598a39]
```

**Result:** First instanciate of CNF was right. Second one no because helm release name is used in first instanciate of CNF, that's why error log appear.

### 6 update of CNF via CLI (helm release update --set XX.XX=YY) (operation)

#### 6.1. Function definition

```
def update_via_cli(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL,SETS,wait_health,auto,uider)
```

**Parameters:**

* **commands**=load commands from commands_list as template (helm -n {NAMESPACE} upgrade {NAME_HELM_DEP} {CHART_NAME_URL} {SETS})
* **NAMESPACE**=namespace name
* **NAME_HELM_DEP**=CNF name (helm release name)
* **CHART_NAME_URL**=url for chart
* **SETS**= set pameters for change
* **wait_health**=timer,sleep time for health check of pod
* **auto**=rollback after not good state of helmrelease pods (True/False)
* **uider**=uuid identificator (generated in main.py)

**Short description:**
1. Some CNF is running.
2. Replace value in template > create CLI helm comand.
3. Health check of pod (Check if is release in good health via checking pod. If yes then continue and add info to log file, if no then add error to log file and return back from function).
4. Update CNF (helm release) with set.
5. If is operation without error then  continue on 6. If is with error add this error to log.
6. Health check of pod (Check if is  release in good health via checking pod. If yes then add info to log gile, if no then add error to log file and continue on 7 ).
7. Check if is auto equal False. If yes add error to log file. If no rollback CNF via function rollback_cnf.


#### 6.2.1. update of CNF via CLI (right inputs)


**Scenario:** Execute script first time with operation instanciate_CNF in input.yaml. Execute script second time with update_via_CLI in input.yaml with some new value in set. After first execution of script check helm release and compare with helm release from second execution. 

**Input file 1:**
```
- operation: instanciate CNF
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 90
  autorollback: False
```

**CLI output 1:**
```
14:42:52.073  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
14:42:52.094  Namespace is active
14:45:53.796  Health check is good
```

**Log file 1:**
```
25-Jul-22 14:42:52.008 DEBUG - Working on cluster health check [2df9d066-a0c5-4db5-8ad3-9a593c1156c0]
25-Jul-22 14:42:52.073 INFO - Cluster is in good health [2df9d066-a0c5-4db5-8ad3-9a593c1156c0]
25-Jul-22 14:42:52.073 DEBUG - Input parameters:operation:instanciate CNF ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [2df9d066-a0c5-4db5-8ad3-9a593c1156c0]
25-Jul-22 14:42:52.073 DEBUG - Working on instanciation of CNF [2df9d066-a0c5-4db5-8ad3-9a593c1156c0]
25-Jul-22 14:42:52.094 INFO - Namespace nrf is active [2df9d066-a0c5-4db5-8ad3-9a593c1156c0]
25-Jul-22 14:42:52.094 DEBUG - Implemantation of command: helm -n nrf install nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [2df9d066-a0c5-4db5-8ad3-9a593c1156c0]
25-Jul-22 14:45:53.795 INFO - Health check is good [2df9d066-a0c5-4db5-8ad3-9a593c1156c0]
```

**Result 1:** Instanciation_of_CNF was right with schme HTTPS. Helm release is in revision 1 with sbi.scheme https. See output from CLi prompt below.

```
[centos@k8master helm_python]$ helm get all nrftest -n nrf
NAME: nrftest
LAST DEPLOYED: Mon Jul 25 14:42:52 2022
NAMESPACE: nrf
STATUS: deployed
REVISION: 1
USER-SUPPLIED VALUES:
db:
  enabled: true
fullnameOverride: ""
global:
  nrf:
    service:
      name: nrf-nnrf
      nodePort: "30800"
      port: "8000"
      type: ClusterIP
  projectName: free5gc
  sbi:
    scheme: https
```

**Input file 2:**
```
- operation: update via CLI
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  timer: 10
  autorollback: False
  set: [global.sbi.scheme=http]
```

**CLI output 2:**
```
14:49:14.731  Before operation health check is good
14:49:14.731  Operation is executing
14:49:15.797  Operation is executed
14:49:26.818  After operation health check is good
14:49:26.864  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Mon Jul 25 14:42:52 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Mon Jul 25 14:49:15 2022	deployed  	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
```

**Log file 2:**
```
25-Jul-22 14:49:03.636 DEBUG - Working on cluster health check [b3228e1e-8095-4d15-a0c4-903817de6666]
25-Jul-22 14:49:03.695 INFO - Cluster is in good health [b3228e1e-8095-4d15-a0c4-903817de6666]
25-Jul-22 14:49:03.696 DEBUG - Input parameters:operation:update via CLI ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,timer:10 ,autorollback:False ,set:['global.sbi.scheme=http']  [b3228e1e-8095-4d15-a0c4-903817de6666]
25-Jul-22 14:49:03.696 DEBUG - Working update via CLI [b3228e1e-8095-4d15-a0c4-903817de6666]
25-Jul-22 14:49:14.731 INFO - Before operation health check is good  [b3228e1e-8095-4d15-a0c4-903817de6666]
25-Jul-22 14:49:14.731 DEBUG - Implementation of command: helm -n nrf upgrade nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz --set global.sbi.scheme=http  [b3228e1e-8095-4d15-a0c4-903817de6666]
25-Jul-22 14:49:26.818 INFO - After operation health check is good  [b3228e1e-8095-4d15-a0c4-903817de6666]
```

**Result 2:** update_via_cli (helm release upgrade) was right. Helm release is in revision 2 with sbi.scheme http. See output from CLI prompt below.
```
[centos@k8master helm_python]$ helm get all nrftest -n nrf
NAME: nrftest
LAST DEPLOYED: Mon Jul 25 14:49:15 2022
NAMESPACE: nrf
STATUS: deployed
REVISION: 2
USER-SUPPLIED VALUES:
global:
  sbi:
    scheme: http
```


#### 6.2.2. update of CNF via CLI with bad health check with autorollback equal False


**Scenario:** Execute script first time with operation instanciate_CNF in input.yaml. Execute script second time with update_via_CLI in input.yaml with some new value in set, with autorollback set to False. After first execution of script check helm release and compare with helm release from second execution. 

**Input file 1, Log file 1, Result 1, CLI output 2** same as in 6.2.1


**Input file 2:**
```
- operation: update via CLI
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  timer: 10
  autorollback: False
  set: [global.sbi.scheme=http]
```

**CLI output 2:**
```
25-Jua-22  Input for operation as json:
{
    "operation": "update via CLI",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "timer": 10,
    "autorollback": false,
    "set": [
        "global.sbi.scheme=http"
    ]
}
14:58:29.457  Before operation health check is good
14:58:29.457  Operation is executing
14:58:30.453  Operation is executed
14:58:51.512  Error After operation health check is not good. Rollback is set to: False
14:58:51.513  Please check status of pods
14:58:51.560  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Mon Jul 25 14:55:17 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Mon Jul 25 14:58:30 2022	deployed  	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete

```

**Log file 2:**
```
25-Jul-22 14:58:18.435 INFO - Cluster is in good health [e09803ce-1ed3-4ed1-ab40-d53105e91283]
25-Jul-22 14:58:18.435 DEBUG - Input parameters:operation:update via CLI ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,timer:10 ,autorollback:False ,set:['global.sbi.scheme=http']  [e09803ce-1ed3-4ed1-ab40-d53105e91283]
25-Jul-22 14:58:18.435 DEBUG - Working update via CLI [e09803ce-1ed3-4ed1-ab40-d53105e91283]
25-Jul-22 14:58:29.457 INFO - Before operation health check is good  [e09803ce-1ed3-4ed1-ab40-d53105e91283]
25-Jul-22 14:58:29.457 DEBUG - Implementation of command: helm -n nrf upgrade nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz --set global.sbi.scheme=http  [e09803ce-1ed3-4ed1-ab40-d53105e91283]
25-Jul-22 14:58:51.512 ERROR - After operation health check is not good  [e09803ce-1ed3-4ed1-ab40-d53105e91283]
25-Jul-22 14:58:51.512 INFO - Rollback in case of failure is set to False [e09803ce-1ed3-4ed1-ab40-d53105e91283]
```

**Result 2:** update_via_cli (helm release upgrade) was not right (health check not good), rollback is set to False so no more actions. 

#### 6.2.3. update of CNF via CLI with bad health check with autorollback equal True


**Scenario:** Execute script first time with operation instanciate_CNF in input.yaml. Execute script second time with update_via_CLI in input.yaml with some new value in set, with autorollback set to False. After first execution of script check helm release and compare with helm release from second execution. 

**Input file 1, Log file, Result 1:** same as in 6.2.1


**Input file 2:**
```
- operation: update via CLI
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  timer: 10
  autorollback: True
  set: [global.sbi.scheme=http]
```

**CLI output 2:**
```
15:08:07.986  Input for operation as json: 
{
    "operation": "update via CLI",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "timer": 10,
    "autorollback": true,
    "set": [
        "global.sbi.scheme=http"
    ]
}
15:08:19.016  Before operation health check is good
15:08:19.016  Operation is executing
15:08:19.933  Operation is executed
15:08:40.989  Error After operation health check is not good. Rollback is set to: True
15:08:52.251  After rollback health check is good
15:08:52.303  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Mon Jul 25 15:05:05 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Mon Jul 25 15:08:19 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
3       	Mon Jul 25 15:08:41 2022	deployed  	free5gc-nrf-0.1.0	v3.0.5     	Rollback to 1   
```

**Log file 2:**
```
25-Jul-22 15:08:07.920 DEBUG - Working on cluster health check [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:07.986 INFO - Cluster is in good health [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:07.987 DEBUG - Input parameters:operation:update via CLI ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,timer:10 ,autorollback:True ,set:['global.sbi.scheme=http']  [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:07.987 DEBUG - Working update via CLI [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:19.015 INFO - Before operation health check is good  [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:19.016 DEBUG - Implementation of command: helm -n nrf upgrade nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz --set global.sbi.scheme=http  [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:40.989 ERROR - After operation health check is not good  [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:40.989 INFO - Rollback in case of failure is set to True [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:40.989 DEBUG - Working on rollback [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:41.035 DEBUG - Implementation of command: helm rollback -n nrf nrftest 1 [67fcd018-d649-493c-a84c-6765ae570818]
25-Jul-22 15:08:52.250 INFO - After operation health check is good  [67fcd018-d649-493c-a84c-6765ae570818]
```

**Result 2:** update_via_cli (helm release upgrade) was not right (health check not good), rollback is set to True so rollback to previous version. 

### 7 update of CNF via YAML (helm release upgrade values.yaml) (operation)

#### 7.1. Function definition

```
def update_via_yaml(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL, CHART_VALUES_URL,wait_health,auto,uider)
```

**Parameters:**

* **commands**=load commands from commands_list as template (helm -n {NAMESPACE} install {NAME_HELM_DEP} {CHART_NAME_URL} -f {CHART_VALUES_URL})
* **NAMESPACE**=namespace name
* **NAME_HELM_DEP**=CNF name (helm release name)
* **CHART_NAME_URL**=url for chart
* **CHART_VALUES_URL**= **changed** yaml files
* **wait_health**=timer, sleep time for health check of pod
* **auto**=rollback after not good state of helmrelease pods (True/False)
* **uider**=uuid identificator (generated in main.py)


**Short description:**
1. Some CNF is running.
2. Replace value in template > create CLI helm comand.
3. Health check of pod (Check if is release in good health via checking pod. If yes then continue and add info to log file, if no then add error to log file and return back from function).
4. Update CNF (helm release) with change in yaml.
5. If is operation without error then  continue on 6. If is with error add this error to log.
6. Health check of pod (Check if is  release in good health via checking pod. If yes then add info to log gile, if no then add error to log file and continue to 7 ).
7. Check if is auto equal False. If yes add error to log file. If no rollback CNF via function def rollback_cnf.



#### 7.2. Function example


**Scenario:**  Execute script first time with operation instanciate_CNF in input.csv. Execute script second time with update_via_yaml in input.csv with changed yaml file in github repo. After first execution of script check helm release and compare with helm release from second execution. Scenarios with incorrect health check of pods/error value in parameters/problem are not shown because result is the same as in 6.2.1./ 6.2.2..

**Input file 1:**
```
- operation: instanciate CNF
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 90
  autorollback: False
```

**CLI output 1:**
```
07:41:17.744  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
07:41:18.599  Namespace is active
07:45:00.573  Health check is good
```

**Log file 1:**
```
26-Jul-22 07:41:16.572 DEBUG - Working on cluster health check [3ea4451c-3f70-40a8-b35b-10bf9153e96c]
26-Jul-22 07:41:17.744 INFO - Cluster is in good health [3ea4451c-3f70-40a8-b35b-10bf9153e96c]
26-Jul-22 07:41:17.744 DEBUG - Input parameters:operation:instanciate CNF ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [3ea4451c-3f70-40a8-b35b-10bf9153e96c]
26-Jul-22 07:41:17.744 DEBUG - Working on instanciation of CNF [3ea4451c-3f70-40a8-b35b-10bf9153e96c]
26-Jul-22 07:41:18.599 INFO - Namespace nrf is active [3ea4451c-3f70-40a8-b35b-10bf9153e96c]
26-Jul-22 07:41:18.599 DEBUG - Implemantation of command: helm -n nrf install nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [3ea4451c-3f70-40a8-b35b-10bf9153e96c]
26-Jul-22 07:45:00.573 INFO - Health check is good [3ea4451c-3f70-40a8-b35b-10bf9153e96c]
```

**Result 1:** Instanciation_of_CNF was right with schme HTTPS. Helm release is in revision 1 with sbi.scheme https. See picture from github values.yaml below and output from CLI. 

![Instanciation_of_CNF](pic/8.PNG "Instanciation_of_CNF_yaml") 

```
[centos@k8master helm_python]$ helm get all nrftest -n nrf
NAME: nrftest
LAST DEPLOYED: Tue Jul 26 07:41:51 2022
NAMESPACE: nrf
STATUS: deployed
REVISION: 1
USER-SUPPLIED VALUES:
db:
  enabled: true
fullnameOverride: ""
global:
  nrf:
    service:
      name: nrf-nnrf
      nodePort: "30800"
      port: "8000"
      type: ClusterIP
  projectName: free5gc
  sbi:
    scheme: https
```

**Input file 2:**
```
- operation: update via yaml
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 10
  autorollback: False
```

**CLI output 2:**
```
07:48:54.562  Input for operation as json: 
{
    "operation": "update via yaml",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 10,
    "autorollback": false
}
07:49:08.456  Before operation health check is good
07:49:08.456  Operation is executing
07:50:02.249  Operation is executed
07:50:14.247  After operation health check is good
07:50:14.698  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Tue Jul 26 07:41:51 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Tue Jul 26 07:49:56 2022	deployed  	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
```

**Log file 2:**
```
26-Jul-22 07:48:53.603 DEBUG - Working on cluster health check [f3ea1a1f-e1ec-429f-85e2-06834375744e]
26-Jul-22 07:48:54.561 INFO - Cluster is in good health [f3ea1a1f-e1ec-429f-85e2-06834375744e]
26-Jul-22 07:48:54.562 DEBUG - Input parameters:operation:update via yaml ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:10 ,autorollback:False  [f3ea1a1f-e1ec-429f-85e2-06834375744e]
26-Jul-22 07:48:54.562 DEBUG - Working update via yaml [f3ea1a1f-e1ec-429f-85e2-06834375744e]
26-Jul-22 07:49:08.456 INFO - Before operation health check is good  [f3ea1a1f-e1ec-429f-85e2-06834375744e]
26-Jul-22 07:50:14.246 INFO - After operation health check is good  [f3ea1a1f-e1ec-429f-85e2-06834375744e]
```


**Result 2:** update_via_yaml (helm release upgrade) was right. Helm release is in revision 2 with sbi.scheme http.  See picture belows from github values.yaml with sbi.scheme https and CLI output with helm revision and sbi.scheme http.

![Instanciation_of_CNF](pic/10.PNG "Instanciation_of_CNF_yaml") 

```
[centos@k8master helm_python]$ helm get all nrftest -n nrf
NAME: nrftest
LAST DEPLOYED: Tue Jul 26 07:49:56 2022
NAMESPACE: nrf
STATUS: deployed
REVISION: 2
USER-SUPPLIED VALUES:
db:
  enabled: true
fullnameOverride: ""
global:
  nrf:
    service:
      name: nrf-nnrf
      nodePort: "30800"
      port: "8000"
      type: ClusterIP
  projectName: free5gc
  sbi:
    scheme: http
```

### 8 upgrade_chart_version (helm release upgrade chart version) (operation)

#### 8.1. Function definition

```
def upgrade_chart_version(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL, CHART_VALUES_URL,wait_health,uider)
```

**Parameters:**
* **commands**=load commands from commands_list as template (helm -n {NAMESPACE} upgrade {NAME_HELM_DEP} {CHART_NAME_URL} -f {CHART_VALUES_URL})
* **NAMESPACE**=namespace name
* **NAME_HELM_DEP**=CNF name (helm release name)
* **CHART_NAME_URL**=url for chart
* **CHART_VALUES_URL**= url for **new** chart
* **wait_health**=sleep time for health check of pod
* **uider**=uuid identificator (generated in main.py)

**Short description:**
1. Some CNF is running.
2. Replace value in template > create CLI helm comand.
3. Health check of pod (Check if is release in good health via checking pod. If yes then continue and add info to log file, if no then add error to log file and return back from function).
4. Update CNF chart version (helm releas upgrade) with change in yaml.
5. If is operation without error then  continue on 6. If is with error add this error to log.
6. Health check of pod (Check if is  release in good health via checking pod. If yes then add info to log gile, if no then add error to log file ).



#### 8.2. Function example


#### 8.2.1. Upgrade_chart_version (helm upgrade)  with not good health check

**Scenario**  Execute script  with operation instanciate_CNF, upgrade_chart_version (skip one version) in input.yaml with autorollback equal to False. 

**Input file:**
```
- operation: instanciate CNF
  namespace: nrf
  cnf_name: nrftest 
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 90
  autorollback: False

- operation: update chart
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.2.1.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 10
  autorollback: False
```

**CLI output :**
```
08:00:33.061  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
08:00:35.801  Namespace is active
08:04:14.537  Health check is good
08:04:14.607  Input for operation as json: 
{
    "operation": "update chart",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.2.1.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 10,
    "autorollback": false
}
08:04:26.947  Before operation health check is good
08:04:26.947  Operation is executing
08:05:00.203  Operation is executed
08:05:32.302  Error After operation health check is not good. Rollback is set to: False
08:05:32.303  Please check status of pods
08:05:32.351  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Tue Jul 26 08:01:11 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Tue Jul 26 08:04:53 2022	deployed  	free5gc-nrf-0.2.1	v3.1.1     	Upgrade complete
```

**Log file**
```
26-Jul-22 08:00:32.333 DEBUG - Working on cluster health check [dc6edc8d-2fd5-4b83-b58d-cb3ba0ecd90f]
26-Jul-22 08:00:33.061 INFO - Cluster is in good health [dc6edc8d-2fd5-4b83-b58d-cb3ba0ecd90f]
26-Jul-22 08:00:33.062 DEBUG - Input parameters:operation:instanciate CNF ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [dc6edc8d-2fd5-4b83-b58d-cb3ba0ecd90f]
26-Jul-22 08:00:33.062 DEBUG - Working on instanciation of CNF [dc6edc8d-2fd5-4b83-b58d-cb3ba0ecd90f]
26-Jul-22 08:00:35.801 INFO - Namespace nrf is active [dc6edc8d-2fd5-4b83-b58d-cb3ba0ecd90f]
26-Jul-22 08:00:35.801 DEBUG - Implemantation of command: helm -n nrf install nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [dc6edc8d-2fd5-4b83-b58d-cb3ba0ecd90f]
26-Jul-22 08:04:14.537 INFO - Health check is good [dc6edc8d-2fd5-4b83-b58d-cb3ba0ecd90f]
26-Jul-22 08:04:14.538 DEBUG - Working on cluster health check [dc09c318-61ec-4533-bd01-00696398dc9d]
26-Jul-22 08:04:14.607 INFO - Cluster is in good health [dc09c318-61ec-4533-bd01-00696398dc9d]
26-Jul-22 08:04:14.608 DEBUG - Input parameters:operation:update chart ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.2.1.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:10 ,autorollback:False  [dc09c318-61ec-4533-bd01-00696398dc9d]
26-Jul-22 08:04:14.608 DEBUG - Working on update chart [dc09c318-61ec-4533-bd01-00696398dc9d]
26-Jul-22 08:04:26.947 DEBUG - Implementation of command: helm -n nrf upgrade nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.2.1.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [dc09c318-61ec-4533-bd01-00696398dc9d]
26-Jul-22 08:05:32.302 ERROR - After operation health check is not good  [dc09c318-61ec-4533-bd01-00696398dc9d]
26-Jul-22 08:05:32.302 INFO - Rollback in case of failure is set to False [dc09c318-61ec-4533-bd01-00696398dc9d]
26-Jul-22 08:05:32.303 WARNING - Please check status of pods [dc09c318-61ec-4533-bd01-00696398dc9d]
```

**Result** Implemantation of operations were good. But health check of pods no, beceause one pod is in status CrashLoopBackOff thas why we have error see output from CLI below.

```
[centos@k8master helm_python]$ kubectl get pods -n nrf
NAME                                       READY   STATUS             RESTARTS   AGE
mongodb-0                                  1/1     Running            0          4m16s
nrftest-free5gc-nrf-nrf-698b684f7d-9crgp   0/1     CrashLoopBackOff   1          30s
nrftest-free5gc-nrf-nrf-75f599497d-dkxsf   1/1     Running            0          4m16s
```

#### 8.2.2. Upgrade_chart_version (helm upgrade) with  good health check

**Scenario**  Execute script  with operation instanciate_CNF, upgrade_chart_version in input.yaml.

**Input file:**
```
- operation: instanciate CNF
  namespace: nrf
  cnf_name: nrftest 
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 90
  autorollback: False

- operation: update chart
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.1.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 10
  autorollback: False
```

**CLI output :**
```
08:07:56.970  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
08:07:56.991  Namespace is active
08:11:07.215  Health check is good
08:11:07.286  Input for operation as json: 
{
    "operation": "update chart",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.1.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 10,
    "autorollback": false
}
08:11:18.342  Before operation health check is good
08:11:18.342  Operation is executing
08:11:24.909  Operation is executed
08:11:35.935  After operation health check is good
08:11:35.986  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Tue Jul 26 08:08:05 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Tue Jul 26 08:11:24 2022	deployed  	free5gc-nrf-0.1.1	v3.0.6     	Upgrade complete
```

**Log file**
```
26-Jul-22 08:07:56.907 DEBUG - Working on cluster health check [57818f44-3e7c-4e97-9247-44937aa32af9]
26-Jul-22 08:07:56.970 INFO - Cluster is in good health [57818f44-3e7c-4e97-9247-44937aa32af9]
26-Jul-22 08:07:56.971 DEBUG - Input parameters:operation:instanciate CNF ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [57818f44-3e7c-4e97-9247-44937aa32af9]
26-Jul-22 08:07:56.971 DEBUG - Working on instanciation of CNF [57818f44-3e7c-4e97-9247-44937aa32af9]
26-Jul-22 08:07:56.991 INFO - Namespace nrf is active [57818f44-3e7c-4e97-9247-44937aa32af9]
26-Jul-22 08:07:56.991 DEBUG - Implemantation of command: helm -n nrf install nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [57818f44-3e7c-4e97-9247-44937aa32af9]
26-Jul-22 08:11:07.215 INFO - Health check is good [57818f44-3e7c-4e97-9247-44937aa32af9]
26-Jul-22 08:11:07.215 DEBUG - Working on cluster health check [0f87a38e-cc30-4bca-bad7-5e2549e3917d]
26-Jul-22 08:11:07.286 INFO - Cluster is in good health [0f87a38e-cc30-4bca-bad7-5e2549e3917d]
26-Jul-22 08:11:07.286 DEBUG - Input parameters:operation:update chart ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.1.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:10 ,autorollback:False  [0f87a38e-cc30-4bca-bad7-5e2549e3917d]
26-Jul-22 08:11:07.286 DEBUG - Working on update chart [0f87a38e-cc30-4bca-bad7-5e2549e3917d]
26-Jul-22 08:11:18.342 DEBUG - Implementation of command: helm -n nrf upgrade nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.1.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [0f87a38e-cc30-4bca-bad7-5e2549e3917d]
26-Jul-22 08:11:35.935 INFO - After operation health check is good  [0f87a38e-cc30-4bca-bad7-5e2549e3917d]
```

**Result**  Implemantation of operations were good. Health check of pods also.


### 9 rollback_cnf (helm release rollback revision) (operation)

#### 9.1. Function definition

```
def rollback_revision_CNF(commands,NAMESPACE,NAME_HELM_DEP,OLD_HELM_REVISION_BACK,wait_health,uider)
```

**Parameters:**
* **commands**=load commands from commands_list as template (helm rollback -n {NAMESPACE} {NAME_HELM_DEP} {LAST_REVISION-OLD_HELM_REVISION})
* **NAMESPACE**=namespace name
* **NAMESPACE**=namespace name
* **NAME_HELM_DEP**=CNF name (helm release name)
* **OLD_HELM_REVISION_BACK**=rollback_back_revision,revision number, how many revisions do we want to return  (please consider that in HELM3, you can return back just 10 revision (default value, can be different))
* **wait_health**=sleep time for health check of pod
* **uider**=uuid identificator (generated in main.py)

**Short description:**

1. CNF is running.
2. Replace value in template > create CLI helm comand.
3. Health check (Check if is release in good health via checking pod. If yes then continue and add info to log file, if no then add error to log file and return back from function).
4. If is return revison < actual - 10 then continue, if no then add to log file Revision back is not Possible.
5. Rollback of CNF.
6. If is operation without error then  continue on 7. If is with error print error message
7. Health check of pod (Check if is  release in good health via checking pod. If yes then add info to log gile, if no then add error to log file ).


#### 9.2. Function example

#### 9.2.1. Rollback one revision back

**Scenario** Execute script with operation instanciate_CNF, several updates, rollback_cnf (1 revision return) in input.yaml. 

**Input file:**
```
- operation: instanciate CNF
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 90
  autorollback: False

- operation: update via CLI
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  timer: 10
  autorollback: False
  set: [global.sbi.scheme=https]

- operation: update chart
  namespace: nrf
  cnf_name: nrftest
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.1.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 10
  autorollback: False


- operation: rollback CNF
  namespace: nrf
  cnf_name: nrftest
  rolback_back_version: 2
  timer: 5
```

**CLI output:**
```
08:37:15.597  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
08:37:15.617  Namespace is active
08:40:17.878  Health check is good
08:40:17.943  Input for operation as json: 
{
    "operation": "update via CLI",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "timer": 10,
    "autorollback": false,
    "set": [
        "global.sbi.scheme=https"
    ]
}
08:40:28.972  Before operation health check is good
08:40:28.972  Operation is executing
08:40:29.865  Operation is executed
08:40:50.920  After operation health check is good
08:40:50.967  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Tue Jul 26 08:37:16 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Tue Jul 26 08:40:29 2022	deployed  	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
08:40:51.024  Input for operation as json: 
{
    "operation": "update chart",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.1.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 10,
    "autorollback": false
}
08:41:02.042  Before operation health check is good
08:41:02.043  Operation is executing
08:41:03.128  Operation is executed
08:41:14.157  After operation health check is good
08:41:14.206  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Tue Jul 26 08:37:16 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Tue Jul 26 08:40:29 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
3       	Tue Jul 26 08:41:02 2022	deployed  	free5gc-nrf-0.1.1	v3.0.6     	Upgrade complete
08:41:14.261  Input for operation as json: 
{
    "operation": "rollback CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "rolback_back_version": 2,
    "timer": 5
}
08:41:20.285  Before operation health check is good
08:41:20.332  Operation is executing
08:41:20.531  Operation is executed
08:41:26.566  After operation health check is good
08:41:26.616  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
1       	Tue Jul 26 08:37:16 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Install complete
2       	Tue Jul 26 08:40:29 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
3       	Tue Jul 26 08:41:02 2022	superseded	free5gc-nrf-0.1.1	v3.0.6     	Upgrade complete
4       	Tue Jul 26 08:41:20 2022	deployed  	free5gc-nrf-0.1.0	v3.0.5     	Rollback to 1   
```

**Log file**
```
26-Jul-22 08:37:15.538 DEBUG - Working on cluster health check [a0a5c978-6436-4e7f-bfe6-9650ceef90cc]
26-Jul-22 08:37:15.597 INFO - Cluster is in good health [a0a5c978-6436-4e7f-bfe6-9650ceef90cc]
26-Jul-22 08:37:15.597 DEBUG - Input parameters:operation:instanciate CNF ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [a0a5c978-6436-4e7f-bfe6-9650ceef90cc]
26-Jul-22 08:37:15.597 DEBUG - Working on instanciation of CNF [a0a5c978-6436-4e7f-bfe6-9650ceef90cc]
26-Jul-22 08:37:15.617 INFO - Namespace nrf is active [a0a5c978-6436-4e7f-bfe6-9650ceef90cc]
26-Jul-22 08:37:15.617 DEBUG - Implemantation of command: helm -n nrf install nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [a0a5c978-6436-4e7f-bfe6-9650ceef90cc]
26-Jul-22 08:40:17.878 INFO - Health check is good [a0a5c978-6436-4e7f-bfe6-9650ceef90cc]
26-Jul-22 08:40:17.878 DEBUG - Working on cluster health check [43a5d0c6-0fba-48f3-8ef7-f1c7c884c7fd]
26-Jul-22 08:40:17.942 INFO - Cluster is in good health [43a5d0c6-0fba-48f3-8ef7-f1c7c884c7fd]
26-Jul-22 08:40:17.943 DEBUG - Input parameters:operation:update via CLI ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,timer:10 ,autorollback:False ,set:['global.sbi.scheme=https']  [43a5d0c6-0fba-48f3-8ef7-f1c7c884c7fd]
26-Jul-22 08:40:17.943 DEBUG - Working update via CLI [43a5d0c6-0fba-48f3-8ef7-f1c7c884c7fd]
26-Jul-22 08:40:28.972 INFO - Before operation health check is good  [43a5d0c6-0fba-48f3-8ef7-f1c7c884c7fd]
26-Jul-22 08:40:28.972 DEBUG - Implementation of command: helm -n nrf upgrade nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz --set global.sbi.scheme=https  [43a5d0c6-0fba-48f3-8ef7-f1c7c884c7fd]
26-Jul-22 08:40:50.920 INFO - After operation health check is good  [43a5d0c6-0fba-48f3-8ef7-f1c7c884c7fd]
26-Jul-22 08:40:50.967 DEBUG - Working on cluster health check [4a040b8d-deea-4832-80fd-59ce5fbc1fbb]
26-Jul-22 08:40:51.023 INFO - Cluster is in good health [4a040b8d-deea-4832-80fd-59ce5fbc1fbb]
26-Jul-22 08:40:51.024 DEBUG - Input parameters:operation:update chart ,namespace:nrf ,cnf_name:nrftest ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.1.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:10 ,autorollback:False  [4a040b8d-deea-4832-80fd-59ce5fbc1fbb]
26-Jul-22 08:40:51.024 DEBUG - Working on update chart [4a040b8d-deea-4832-80fd-59ce5fbc1fbb]
26-Jul-22 08:41:02.043 DEBUG - Implementation of command: helm -n nrf upgrade nrftest https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.1.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [4a040b8d-deea-4832-80fd-59ce5fbc1fbb]
26-Jul-22 08:41:14.157 INFO - After operation health check is good  [4a040b8d-deea-4832-80fd-59ce5fbc1fbb]
26-Jul-22 08:41:14.206 DEBUG - Working on cluster health check [627ed53e-68ac-40d6-8411-b561a505fa6b]
26-Jul-22 08:41:14.260 INFO - Cluster is in good health [627ed53e-68ac-40d6-8411-b561a505fa6b]
26-Jul-22 08:41:14.261 DEBUG - Input parameters:operation:rollback CNF ,namespace:nrf ,cnf_name:nrftest ,rolback_back_version:2 ,timer:5  [627ed53e-68ac-40d6-8411-b561a505fa6b]
26-Jul-22 08:41:14.261 DEBUG - Working on rollback of CNF [627ed53e-68ac-40d6-8411-b561a505fa6b]
26-Jul-22 08:41:20.285 INFO - Before operation health check is good  [627ed53e-68ac-40d6-8411-b561a505fa6b]
26-Jul-22 08:41:20.332 DEBUG - Implementation of command: helm rollback -n nrf nrftest 1 [627ed53e-68ac-40d6-8411-b561a505fa6b]
26-Jul-22 08:41:26.566 INFO - After operation health check is good  [627ed53e-68ac-40d6-8411-b561a505fa6b]
```

**Result** Implemantation was good. Rollback to revision 1 back was successful . 

#### 9.2.2. Rollback on revision which doesn't exist

**Scenario** Execute script with previos result with rollback_back_revisions 5pytho in input.yaml. 


**Input file:**
```
- operation: rollback CNF
  namespace: nrf
  cnf_name: nrftest
  rolback_back_version: 5
  timer: 5
```

**CLI output: **
```
08:43:28.483  Input for operation as json: 
{
    "operation": "rollback CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "rolback_back_version": 5,
    "timer": 5
}
08:43:34.518  Before operation health check is good
08:43:34.567  Operation is executing
08:43:34.602  Operation is executed
08:43:34.603  Error: unknown shorthand flag: '1' in -1
```

**Log file**
```
26-Jul-22 08:43:28.416 DEBUG - Working on cluster health check [6ba490a5-7631-416e-96e8-33ad2ed1c5df]
26-Jul-22 08:43:28.483 INFO - Cluster is in good health [6ba490a5-7631-416e-96e8-33ad2ed1c5df]
26-Jul-22 08:43:28.483 DEBUG - Input parameters:operation:rollback CNF ,namespace:nrf ,cnf_name:nrftest ,rolback_back_version:5 ,timer:5  [6ba490a5-7631-416e-96e8-33ad2ed1c5df]
26-Jul-22 08:43:28.484 DEBUG - Working on rollback of CNF [6ba490a5-7631-416e-96e8-33ad2ed1c5df]
26-Jul-22 08:43:34.518 INFO - Before operation health check is good  [6ba490a5-7631-416e-96e8-33ad2ed1c5df]
26-Jul-22 08:43:34.567 DEBUG - Implementation of command: helm rollback -n nrf nrftest -1 [6ba490a5-7631-416e-96e8-33ad2ed1c5df]
26-Jul-22 08:43:34.602 ERROR - Implemantation of command: Error: unknown shorthand flag: '1' in -1 [6ba490a5-7631-416e-96e8-33ad2ed1c5df]
26-Jul-22 08:43:34.602 WARNING - Please check input parameters [6ba490a5-7631-416e-96e8-33ad2ed1c5df]
```

**Result** Implemantation is with error beceause we can not return on revision which doesn't exist (5 revision back).

#### 9.2.3. Rollback  revision more then 10 return

**Scenario** Execute script with previous result and add operations instanciate_CNF, upgrade_chart_version,update_via_CLI, rollback_cnf more times and rollback_back_revisions (13 revision return) in input.csv. 

**Input file:**
```
---
- operation: rollback CNF
  namespace: nrf
  cnf_name: nrftest
  rolback_back_version: 9
  timer: 5


- operation: rollback CNF
  namespace: nrf
  cnf_name: nrftest
  rolback_back_version: 11
  timer: 5
```

**CLI output:**
```
08:54:06.711  Input for operation as json: 
{
    "operation": "rollback CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "rolback_back_version": 9,
    "timer": 5
}
08:54:12.735  Before operation health check is good
08:54:12.801  Operation is executing
08:54:13.053  Operation is executed
08:54:19.087  After operation health check is good
08:54:19.155  helm history nrftest -n nrf
REVISION	UPDATED                 	STATUS    	CHART            	APP VERSION	DESCRIPTION     
6       	Tue Jul 26 08:50:41 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
7       	Tue Jul 26 08:51:14 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
8       	Tue Jul 26 08:51:42 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Rollback to 5   
9       	Tue Jul 26 08:52:00 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
10      	Tue Jul 26 08:52:23 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
11      	Tue Jul 26 08:52:40 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Rollback to 9   
12      	Tue Jul 26 08:52:59 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
13      	Tue Jul 26 08:53:22 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
14      	Tue Jul 26 08:53:45 2022	superseded	free5gc-nrf-0.1.0	v3.0.5     	Upgrade complete
15      	Tue Jul 26 08:54:12 2022	deployed  	free5gc-nrf-0.1.0	v3.0.5     	Rollback to 5   
08:54:19.211  Input for operation as json: 
{
    "operation": "rollback CNF",
    "namespace": "nrf",
    "cnf_name": "nrftest",
    "rolback_back_version": 11,
    "timer": 5
}
08:54:25.237  Before operation health check is good
08:54:25.302  Revision back is not possible. Please check input parameters
```

**Log file**
```
26-Jul-22 08:54:06.711 DEBUG - Working on rollback of CNF [746d694b-4163-4c01-8a27-808cede487b3]
26-Jul-22 08:54:12.735 INFO - Before operation health check is good  [746d694b-4163-4c01-8a27-808cede487b3]
26-Jul-22 08:54:12.801 DEBUG - Implementation of command: helm rollback -n nrf nrftest 5 [746d694b-4163-4c01-8a27-808cede487b3]
26-Jul-22 08:54:19.086 INFO - After operation health check is good  [746d694b-4163-4c01-8a27-808cede487b3]
26-Jul-22 08:54:19.155 DEBUG - Working on cluster health check [ee6e92d4-ee97-4bde-a850-2ff4f9d73e82]
26-Jul-22 08:54:19.211 INFO - Cluster is in good health [ee6e92d4-ee97-4bde-a850-2ff4f9d73e82]
26-Jul-22 08:54:19.211 DEBUG - Input parameters:operation:rollback CNF ,namespace:nrf ,cnf_name:nrftest ,rolback_back_version:11 ,timer:5  [ee6e92d4-ee97-4bde-a850-2ff4f9d73e82]
26-Jul-22 08:54:19.211 DEBUG - Working on rollback of CNF [ee6e92d4-ee97-4bde-a850-2ff4f9d73e82]
26-Jul-22 08:54:25.237 INFO - Before operation health check is good  [ee6e92d4-ee97-4bde-a850-2ff4f9d73e82]
26-Jul-22 08:54:25.302 ERROR - Revision back is not possible  [ee6e92d4-ee97-4bde-a850-2ff4f9d73e82]
26-Jul-22 08:54:25.302 WARNING - Please check input parameters [ee6e92d4-ee97-4bde-a850-2ff4f9d73e82]
```

**Result** Rollback 11 revision back isn't possible. Max number for return revision is 10. 


### 10 delete_CNF (helm release uninstall) (operation)

```
def delete_CNF(commands, NAMESPACE, NAME_HELM_DEP,wait_health,uider):
```

#### 10.1. Function definition

**Parameters:**
* **commands**=load commands from commands_list as template (helm -n {NAMESPACE} install {NAME_HELM_DEP} {CHART_NAME_URL} -f {CHART_VALUES_URL})
* **NAMESPACE**=namespace name
* **NAME_HELM_DEP**=CNF name (helm release name)
* **wait_health**=timer, sleep time for health check of pod
* **uider**=uuid identificator (generated in main.py)

**Short description:**

1. CNF is running.
2. Replace value in template > create CLI helm comand.
3. Check if CNF exist, if no add log.
4. Termination of CNF.
5. If is operation without error then  continue on 6. If is with error then add  error message.
6. Check if is deleted (Check if is release terminated) via checking pod status every second in interval equal wait_health. If is status of pod chanded then add info log, idd pod doesn’t exist add info log, if pod still exist after interval add error log. 


#### 10.2. Function example


#### 10.2.1. Rollback one revision back

**Scenario** Execute script with operations instanciate operation and delete_CNF with short timer  in input.yaml.

**Input file:**
```
- operation: instanciate CNF
  namespace: space
  cnf_name:  nrf
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 90
  autorollback: False

- operation: delete CNF
  namespace: space
  cnf_name: nrf
  timer: 10
```

**CLI output:**
```
12:42:47.004  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "space",
    "cnf_name": "nrf",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
12:42:47.024  Namespace is active
12:42:47.024  Operation is executing
12:42:48.895  Operation is executed
12:45:50.021  Health check is good
12:45:50.084  Input for operation as json: 
{
    "operation": "delete CNF",
    "namespace": "space",
    "cnf_name": "nrf",
    "timer": 10
}
12:45:50.153  Status of pods before deletion mongodb-0 Running,nrf-free5gc-nrf-nrf-7ff8dcbb5d-x9qjj Running
12:45:51.727  Status of pods changed mongodb-0 Terminating,nrf-free5gc-nrf-nrf-7ff8dcbb5d-x9qjj Terminating
12:46:01.356  CNF in actual time not deleted


- operation: instanciate CNF
  namespace: space
  cnf_name:  nrf
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 60
  autorollback: False
```

**Log file**
```
01-Aug-22 12:42:46.940 DEBUG - Working on cluster health check [e3bdba96-62b1-4767-aef1-3cdde2df865a]
01-Aug-22 12:42:47.003 INFO - Cluster is in good health [e3bdba96-62b1-4767-aef1-3cdde2df865a]
01-Aug-22 12:42:47.004 DEBUG - Input parameters:operation:instanciate CNF ,namespace:space ,cnf_name:nrf ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [e3bdba96-62b1-4767-aef1-3cdde2df865a]
01-Aug-22 12:42:47.004 DEBUG - Working on instanciation of CNF [e3bdba96-62b1-4767-aef1-3cdde2df865a]
01-Aug-22 12:42:47.024 INFO - Namespace space is active [e3bdba96-62b1-4767-aef1-3cdde2df865a]
01-Aug-22 12:42:47.024 DEBUG - Implemantation of command: helm -n space install nrf https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [e3bdba96-62b1-4767-aef1-3cdde2df865a]
01-Aug-22 12:45:50.020 INFO - Health check is good [e3bdba96-62b1-4767-aef1-3cdde2df865a]
01-Aug-22 12:45:50.021 DEBUG - Working on cluster health check [b23cb099-b592-4918-8853-ca582709bee8]
01-Aug-22 12:45:50.084 INFO - Cluster is in good health [b23cb099-b592-4918-8853-ca582709bee8]
01-Aug-22 12:45:50.084 DEBUG - Input parameters:operation:delete CNF ,namespace:space ,cnf_name:nrf ,timer:10  [b23cb099-b592-4918-8853-ca582709bee8]
01-Aug-22 12:45:50.084 DEBUG - Working on deletion of CNF [b23cb099-b592-4918-8853-ca582709bee8]
01-Aug-22 12:45:50.153 DEBUG - Status of pods before deletion mongodb-0 Running,nrf-free5gc-nrf-nrf-7ff8dcbb5d-x9qjj Running [b23cb099-b592-4918-8853-ca582709bee8]
01-Aug-22 12:45:51.727 INFO - Status of pods changed mongodb-0 Terminating,nrf-free5gc-nrf-nrf-7ff8dcbb5d-x9qjj Terminating [b23cb099-b592-4918-8853-ca582709bee8]
01-Aug-22 12:46:01.355 ERROR - CNF nrf in namespace space  not deleted. [b23cb099-b592-4918-8853-ca582709bee8]
```

**Result** CNF is note deleted because both pods are in Terminating status.


#### 10.2.2. Rollback one revision back

**Scenario** Execute script with operations instanciate operation and delete_CNF in input.yaml.

**Input file:**
```
- operation: instanciate CNF
  namespace: space
  cnf_name:  nrf
  chart_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz
  value_url: https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml
  timer: 60
  autorollback: False


- operation: delete CNF
  namespace: space
  cnf_name: nrf
  timer: 60
```

**CLI output:**
```
12:49:33.699  Input for operation as json: 
{
    "operation": "instanciate CNF",
    "namespace": "space",
    "cnf_name": "nrf",
    "chart_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz",
    "value_url": "https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml",
    "timer": 90,
    "autorollback": false
}
12:49:33.720  Namespace is active
12:49:33.720  Operation is executing
12:49:35.546  Operation is executed
12:52:36.743  Health check is good
12:52:36.811  Input for operation as json: 
{
    "operation": "delete CNF",
    "namespace": "space",
    "cnf_name": "nrf",
    "timer": 60
}
12:52:36.877  Status of pods before deletion mongodb-0 Running,nrf-free5gc-nrf-nrf-7ff8dcbb5d-q64qk Running
12:52:43.005  Status of pods changed mongodb-0 Terminating,nrf-free5gc-nrf-nrf-7ff8dcbb5d-q64qk Terminating
12:52:46.223  Status of pods changed nrf-free5gc-nrf-nrf-7ff8dcbb5d-q64qk Terminating
12:52:48.361  CNF deleted
```

**Log file**
```
01-Aug-22 12:49:33.635 DEBUG - Working on cluster health check [ea28272c-fa5d-45ff-8864-ddb37fc23cda]
01-Aug-22 12:49:33.698 INFO - Cluster is in good health [ea28272c-fa5d-45ff-8864-ddb37fc23cda]
01-Aug-22 12:49:33.699 DEBUG - Input parameters:operation:instanciate CNF ,namespace:space ,cnf_name:nrf ,chart_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz ,value_url:https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml ,timer:90 ,autorollback:False  [ea28272c-fa5d-45ff-8864-ddb37fc23cda]
01-Aug-22 12:49:33.699 DEBUG - Working on instanciation of CNF [ea28272c-fa5d-45ff-8864-ddb37fc23cda]
01-Aug-22 12:49:33.720 INFO - Namespace space is active [ea28272c-fa5d-45ff-8864-ddb37fc23cda]
01-Aug-22 12:49:33.720 DEBUG - Implemantation of command: helm -n space install nrf https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/repo/free5gc-nrf-0.1.0.tgz -f https://raw.githubusercontent.com/dolukac/towards5gs-helm/main/charts/free5gc/charts/free5gc-nrf/values.yaml [ea28272c-fa5d-45ff-8864-ddb37fc23cda]
01-Aug-22 12:52:36.743 INFO - Health check is good [ea28272c-fa5d-45ff-8864-ddb37fc23cda]
01-Aug-22 12:52:36.743 DEBUG - Working on cluster health check [538bde6b-9d5f-45f8-8301-c474f0ec819f]
01-Aug-22 12:52:36.811 INFO - Cluster is in good health [538bde6b-9d5f-45f8-8301-c474f0ec819f]
01-Aug-22 12:52:36.811 DEBUG - Input parameters:operation:delete CNF ,namespace:space ,cnf_name:nrf ,timer:60  [538bde6b-9d5f-45f8-8301-c474f0ec819f]
01-Aug-22 12:52:36.811 DEBUG - Working on deletion of CNF [538bde6b-9d5f-45f8-8301-c474f0ec819f]
01-Aug-22 12:52:36.877 DEBUG - Status of pods before deletion mongodb-0 Running,nrf-free5gc-nrf-nrf-7ff8dcbb5d-q64qk Running [538bde6b-9d5f-45f8-8301-c474f0ec819f]
01-Aug-22 12:52:43.005 INFO - Status of pods changed mongodb-0 Terminating,nrf-free5gc-nrf-nrf-7ff8dcbb5d-q64qk Terminating [538bde6b-9d5f-45f8-8301-c474f0ec819f]
01-Aug-22 12:52:46.222 INFO - Status of pods changed nrf-free5gc-nrf-nrf-7ff8dcbb5d-q64qk Terminating [538bde6b-9d5f-45f8-8301-c474f0ec819f]
01-Aug-22 12:52:48.361 INFO - CNF nrf in namespace space  deleted. [538bde6b-9d5f-45f8-8301-c474f0ec819f]
```

**Result** CNF deleted correctly.

#### 10.2.3. Delete CNF which doesn’t exist

**Scenario** Execute script with operations  delete_CNF on not exist CNF in input.yaml.

**Input file:**
```
- operation: delete CNF
  namespace: space
  cnf_name: nrf
  timer: 60
```

**CLI output:**
```
12:55:02.150  Input for operation as json: 
{
    "operation": "delete CNF",
    "namespace": "space",
    "cnf_name": "nrf",
    "timer": 60
}
12:55:02.221  CNF already deleted. No further actions needed
```

**Log file**
```
01-Aug-22 12:55:02.085 DEBUG - Working on cluster health check [2e86e782-20de-400f-a93b-fe954ca2b583]
01-Aug-22 12:55:02.150 INFO - Cluster is in good health [2e86e782-20de-400f-a93b-fe954ca2b583]
01-Aug-22 12:55:02.151 DEBUG - Input parameters:operation:delete CNF ,namespace:space ,cnf_name:nrf ,timer:60  [2e86e782-20de-400f-a93b-fe954ca2b583]
01-Aug-22 12:55:02.151 DEBUG - Working on deletion of CNF [2e86e782-20de-400f-a93b-fe954ca2b583]
01-Aug-22 12:55:02.221 INFO - nrf in space already deleted. No further actions needed [2e86e782-20de-400f-a93b-fe954ca2b583]
```

**Result** CNF can not be deleted because doesn’t exist.



