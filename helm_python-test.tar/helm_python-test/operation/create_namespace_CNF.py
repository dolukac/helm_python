import time
import random
from kubernetes import client
#turn off debug logging for library
import logging
logging.getLogger("kubernetes").setLevel(logging.WARNING)
from conf import settings
from conf.log import loger,loger_screen
from conf import loging_text as lt
from operation.commands import exec_command,exec_command_need
from operation.checker import pod_health_check, get_namespaces, check_state_namespace, print_namespaces
from operation.cleaner import delete_CNF

#crate namespace if doesn't exist
def create_namespace(commands,NAMESPACE,wait_health,uider):
    
    #with open('/home/centos/helm_python/operation/command_volume.txt') as file:
    #   data=file.read()
    

    #data=data.replace('{replace_value}', str(random.randint(100000,1000000)))
    #result_com=exec_command_need(data)

    #return result_com
 
    #if namespace doesn't exist in list of namespace then create namespace and add info log
    #if exist add info log
    if NAMESPACE not in get_namespaces(settings.v1):
        settings.v1.create_namespace(client.V1Namespace(metadata=client.V1ObjectMeta(name=NAMESPACE)))
        time.sleep(3)
        for _ in range(3):
            namespaces_alive=print_namespaces()
            if NAMESPACE in namespaces_alive:
                loger('inf','Namespace '+NAMESPACE+ ' created',uider)
                loger_screen('Namespace created')
                
                worker='k8worker4'
                random_str=str(random.randint(100000,1000000))
                with open(settings.help_pod) as file:
                     data=file.read()
                     data=data.replace('{randomnumber}', random_str)
                     data=data.replace('{worker}', worker)
                     result_com=exec_command_need(data)
                     time.sleep(wait_health)
                     delete_help_pod=commands[11]
                     result_com_delete=exec_command_need(delete_help_pod)

                if result_com.endswith('created') and result_com_delete.endswith('deleted'):
                   loger('inf','Directory ' +'helmpython'+random_str+' for persistent volume created in ' +worker,uider)
                   loger_screen('Directory ' +'helmpython'+random_str+' for persistent volume created in ' +worker)
                   with open(settings.command_volume) as file:
                    data=file.read()
                    data=data.replace('{randomnumber}', random_str)
                    data=data.replace('{NAMESPACE}', NAMESPACE)
                    data=data.replace('{worker}', worker)
          
                    result_pv=exec_command_need(data)
                    if result_pv.endswith('created'):
                       loger('inf',result_pv+' ',uider)
                       loger_screen('Persistent volume created')
                       return True
                    else:
                       loger('err',result_com+' ',uider)
                       loger_screen('Persistent volume not created '+ result_com)
                       return False

                else:
                   loger('err','File for volume in namespace not created properly. ',uider)
                   loger_screen('File for volume in namespace not created properly')
       

                

            else:
                time.sleep(wait_health)
        else:
            loger('err','Namespace '+NAMESPACE+ ' not created',uider)
            loger_screen('Namespace not created, please check logs in namespace')
        
        #loger('deb','Namespace '+NAMESPACE+ ' created',uider)
    else:
        loger('inf','Namespace '+NAMESPACE+ ' already exist',uider)
        loger_screen('Namespace already exist')
         
    


#instiate CNF (helm release install)
def instanciate_CNF(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL, CHART_VALUES_URL,wait_health,auto,uider):
    # replace relevant {values} in template command_lists
    instiate_CNF_command=commands[1]
    instiate_CNF_command = instiate_CNF_command.replace('{NAMESPACE}', NAMESPACE)
    instiate_CNF_command = instiate_CNF_command.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
    instiate_CNF_command = instiate_CNF_command.replace('{CHART_NAME_URL}', CHART_NAME_URL)
    instiate_CNF_command = instiate_CNF_command.replace('{CHART_VALUES_URL}', CHART_VALUES_URL)

    #check if namespace exists and is active
    #if is active do instanciation
    #if no add error to log
    name_space_check=check_state_namespace(NAMESPACE)
    if name_space_check == True:
       
        loger('inf','Namespace '+NAMESPACE+ ' is active',uider) 
        loger_screen('Namespace is active')
        loger('deb',lt.imp+instiate_CNF_command,uider)
        #execute command for instanciation CNF (helm release)
        loger_screen(lt.oe)
        deployment_check = exec_command(instiate_CNF_command)
        loger_screen(lt.oe_d)
        #if is everything fine do health check
        #if no add error to log
        if deployment_check == True:
            #check if was instanciation correct via health check (pods need to be running)
            result_health=pod_health_check(NAMESPACE, NAME_HELM_DEP,wait_health)
            if result_health != True:
                loger('err','Health check is not good',uider)
                loger('inf',lt.rl_in+str(auto),uider)
                loger_screen('Error Health check is not good. Rollback is set to: ' +str(auto))
                #check if is autorollback set to False
                #if yes add error log
                #if no delete CNF
                if auto == False:
                   loger('war','Please check status of pods',uider)
                   loger_screen('Please check status of pods')
                else:
                  loger('deb','Working on rollback (deletion of CNF)',uider)
                  
                  delete_CNF(commands,NAMESPACE,NAME_HELM_DEP,wait_health,uider)
            else:
                loger('inf','Health check is good',uider)
                loger_screen('Health check is good')
        else:
            loger('err',lt.imp+deployment_check,uider)
            loger('war',lt.check,uider)
            loger_screen(deployment_check)
    else:
        loger('err','Namespace '+NAMESPACE+ ' is not active',uider)
        loger('war','Please check namespace '+ NAMESPACE,uider)
        loger_screen('Error namespace is not active')










