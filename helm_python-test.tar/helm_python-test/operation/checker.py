import time
from datetime import datetime
from conf.log import loger
from conf import settings
from operation.commands import exec_command_need

#functions for convert list to string
def listToString(s):
        str1 = ""
        for ele in s:
            str1 += ele
        return str1

def listToString2(s):
     str1=' '.join(s)
     return str1

#check health of kubernetes cluster
#if cluster isn't in good health than exit() script
def cluster_health_check(health_command,uider):
    #create actual health of kubernetes cluster
    loger('deb','Working on cluster health check',uider)
    cluster_check=exec_command_need(health_command)
    #load good check of kubernetes cluster
    with open(settings.help_health_compare) as file:
        good_health = file.readlines()
    #if actual state of cluster not equal good state of cluster
    #add error log and stop script
    #if equal add to log cluster is good health
    if cluster_check != listToString(good_health):
        loger('err',"Cluster is not in good health",uider)
        a=cluster_check.splitlines()
        for i in a:
            loger('war',i,uider)
        return exit()
    else:
        loger('inf',"Cluster is in good health",uider)


#get list of all namespaces for function create_namespace
def get_namespaces(v1):
    namespaces_list=[]
    nameSpaceList = settings.v1.list_namespace()

    for nameSpace in nameSpaceList.items:
        namespaces_list.append(nameSpace.metadata.name)
    return namespaces_list

#print all namespaces for function clean_namespace
def print_namespaces():
    namespaces=get_namespaces(settings.v1)
    k=[]
    for i in namespaces:
        k.append(i)

    return k

#check state of namespace for function instanciate_CNF
def check_state_namespace(NAMESPACE):
    if NAMESPACE in get_namespaces(settings.v1):
        exist_namespace = settings.v1.read_namespace(NAMESPACE)
        if exist_namespace.status.phase == 'Active':
            a=exist_namespace.status.phase
            return True
        else:
            a=exist_namespace.status.phase
            return False

#check if are relevants pods running in namespace
def check_health_health(pod_namespace_list,NAME_HELM_DEP,NAMESPACE):
    #for each pod in namespace, if start with name of deployment check if is running (condition based on name can be adjusted)
    #if no, false
    for podNamespace in pod_namespace_list.items:
      if podNamespace.metadata.name.startswith(NAME_HELM_DEP):
          pod_health = settings.v1.read_namespaced_pod(podNamespace.metadata.name,NAMESPACE)
          if pod_health.status.phase == 'Running' and pod_health.status.conditions[1].reason == None:
              pass
          else:
              return False

#health check will be in future replaced by API call
#health check via check running pods for NAMESPACE,HELM_RELEASE
#check health check is executed maximum 3 times with sleep time or less than 3 if is health check already good
#return None if pods are running, return False if they are not
def pod_health_check(NAMESPACE,NAME_HELM_DEP,wait_health):
    #time sleep for process previous operations
    time.sleep(1)
    for _ in range(3):
        #time sleep in time of wait_health for each iteration
        #without this will, be result of pod health check good          
        time.sleep(wait_health)
        #get list list of pods in namespace
        pod_namespace_list = settings.v1.list_namespaced_pod(NAMESPACE)
        #function for checking if are relevant pods running
        #if is false continue in perform health check until count of iterations=4
        a=check_health_health(pod_namespace_list,NAME_HELM_DEP,NAMESPACE)
        if a == None:
           return True

def actual_date_time():
   now=datetime.now()
   dt_string=now.strftime("%d-%b-%y %H:%M:%S")
   return dt_string

def actual_time():
   times=datetime.utcnow().strftime('%H:%M:%S.%f')[:-3] 
   return times


