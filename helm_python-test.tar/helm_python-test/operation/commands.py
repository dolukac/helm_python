import os
import subprocess as sp
import subprocess

#function for execute commad with output
def exec_command_need(command):
    output = sp.getoutput(command)
    return output

#function for execute commad witjpu output, just error output
def exec_command(command):
    output = sp.getoutput(command)
    if output.startswith('Error') or output.startswith('error'):
        return output
    else:
        return True

def exec_command_special(command):
    #output=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    #new=output.decode("utf-8")
    #a=new.replace("\n"," ")
    #return output
    comand_parse=command.split(' ')
    sp=subprocess.Popen(comand_parse,stdout=subprocess.PIPE)
    output=sp.stdout.readlines()
    output_=output[0].decode('utf-8')
    output_comand=output_.split(' ')
    return output_comand[0]
