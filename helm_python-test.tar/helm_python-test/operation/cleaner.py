import time
from conf import settings
from conf.log import loger,loger_screen
from operation.checker import print_namespaces
from operation.commands import exec_command,exec_command_need

#delete namespace
#1. check if namespace exist
#2. delete namespace
#3. check, if is namespaced deleted  3 times, for each loop sleep=wait_health
#4. if no return 'check message' and add information to log
def delete_namespace(NAMESPACE,wait_health,uider):
    namespaces_alive=print_namespaces()

    if NAMESPACE not in namespaces_alive:
        loger('err', 'Namespace ' +NAMESPACE + ' does not exist',uider)
        loger_screen("Namespace doesn't exist")
        return False
    else:
        settings.v1.delete_namespace(NAMESPACE)
        for _ in range(3):
            namespaces_alive=print_namespaces()
            if NAMESPACE not in namespaces_alive:
                loger('inf','Namespace ' +NAMESPACE+  ' deleted',uider)
                loger_screen("Namespace deleted")
                return True
            else:
                time.sleep(wait_health)
    loger('err','Namespace ' +NAMESPACE +' not deleted. Please check namespace logs',uider)
    loger_screen("Error Namespace not deleted")
    return 'Check namespace'


#terminate CNF(delete helm release)
#1. check if CNF (helm release) exist
#2. check if is CNF(helm release) running
#3. delete running CNF(helm release)
#4. check, if is CNF(helm release) terminated beased on status of pod each second
#5. if pods for CNF not exist add info lof, is status of pod changed add info log, if pods still exist until waith_health add error log


def delete_CNF(commands, NAMESPACE, NAME_HELM_DEP,wait_health,uider):
    #check if CNF(helm release exist), if no then add log
    deletion_check_command=commands[12]
    deletion_check_command=deletion_check_command.replace('{NAMESPACE}', NAMESPACE)
    deletion_check_command=deletion_check_command.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
    delete_result=exec_command_need(deletion_check_command)
   
    #check if some pods exists, if no add info log
    if delete_result == "No resources found in space namespace.":
        loger('inf',NAME_HELM_DEP+ ' in ' + NAMESPACE + ' already deleted. No further actions needed',uider)
        loger_screen('CNF already deleted. No further actions needed')
    #if yes exist delete him
    else:
       before=delete_result.replace("\n",",")
       #add actual state of pods
       loger('deb','Status of pods before deletion ' + before,uider)
       loger_screen('Status of pods before deletion ' + before)
       #create comand for deletion CNF and execute him
       terminate_CNF_command = commands[8]
       terminate_CNF_command = terminate_CNF_command.replace('{NAMESPACE}', NAMESPACE)
       terminate_CNF_command = terminate_CNF_command.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
       exec_command(terminate_CNF_command)
       
       #until wait_health check if pods exist
       #or changed
       for _ in range(wait_health):
         time.sleep(1)
         actual=exec_command_need(deletion_check_command)
         actual_rep=actual.replace("\n",",")
        
         if actual_rep == "No resources found in space namespace.":
            loger('inf','CNF '+ NAME_HELM_DEP+ ' in namespace ' + NAMESPACE + '  deleted.',uider)
            loger_screen('CNF deleted')
            return    
         elif actual_rep==before:
            before=actual_rep
         elif actual_rep!=before:
            loger('inf','Status of pods changed ' + actual_rep,uider)
            loger_screen('Status of pods changed ' + actual_rep )
            before=actual_rep
       else:
          loger('err','CNF '+ NAME_HELM_DEP+ ' in namespace ' + NAMESPACE + '  not deleted.',uider)
          loger_screen('CNF in actual time not deleted')
