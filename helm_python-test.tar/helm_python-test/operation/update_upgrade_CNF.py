from operation.checker import pod_health_check
from operation.commands import exec_command, exec_command_need,exec_command_special
import subprocess
from conf.log import loger,loger_screen
from conf import loging_text as lt

#show history of revisions
#in functions can be comment without affect on execution
def update_upgrade_history_check(commands,NAMESPACE,NAME_HELM_DEP):
    #replace relevant {values} in template command_lists
    update_upgrade_history= commands[4]
    update_upgrade_history = update_upgrade_history.replace('{NAMESPACE}', NAMESPACE)
    update_upgrade_history = update_upgrade_history.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
    #execution of command
    update_upgrade_history_S = exec_command_need(update_upgrade_history)
    loger_screen(update_upgrade_history)
    #print("-------- HELM HISTORY UPDATE/UPGRADE ")
    #print(f"Implementation of command: {update_upgrade_history}")
    print(update_upgrade_history_S)

#update CNF(helm release) via CLI
def update_via_cli(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL,SETS,wait_health,auto,uider):

    #check of CNF(helm release) before update
    before_check=pod_health_check(NAMESPACE, NAME_HELM_DEP, wait_health)
    #if is health check state good than continue, if no add error to log
    if before_check == True:
        loger('inf',lt.ht_bf,uider)
        loger_screen(lt.ht_bf)    
        #execution of command
        #replace relevant {values} in template command_lists and execute command
        update_via_cli_command = commands[3]
        update_via_cli_command  = update_via_cli_command.replace('{NAMESPACE}', NAMESPACE)
        update_via_cli_command  = update_via_cli_command.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
        update_via_cli_command  = update_via_cli_command.replace('{CHART_NAME_URL}', CHART_NAME_URL)
        update_via_cli_command  = update_via_cli_command.replace('{SETS}', SETS)

        loger('deb',lt.imp+update_via_cli_command, uider)
        loger_screen(lt.oe)
        update_via_cli_command_check = exec_command(update_via_cli_command )
        loger_screen(lt.oe_d)
        #check if was execution of command True, if yes do health check
        #if no add error to log
        
        if update_via_cli_command_check == True:
            #check of CNF(helm release) after update
            after_health_check=pod_health_check(NAMESPACE, NAME_HELM_DEP,wait_health)
            if after_health_check == True:
                loger('inf',lt.ht_af,uider)
                loger_screen(lt.ht_af)
            else:
                loger('err',lt.ht_af_err,uider)
                loger('inf',lt.rl_in+str(auto),uider)
                loger_screen(lt.ht_af_err_rl +str(auto))
                #check if is autorollback set to False
                #if yes add error log
                #if no delete CNF
                if auto == False:
                  loger('war',lt.pod,uider)
                  loger_screen(lt.pod)
                else:
                  loger('deb',lt.rol,uider)
                  rollback_revision_update(commands,NAMESPACE,NAME_HELM_DEP,1,wait_health,uider)
            # check history of revisions

            update_upgrade_history_check(commands, NAMESPACE, NAME_HELM_DEP)

        else:
            loger('err',lt.imp+update_via_cli_command_check,uider)
            loger('war',lt.check,uider)
            loger_screen(update_via_cli_command_check)
    else:
        loger('err',lt.ht_bf_err,uider)
        loger('war',lt.pod,uider)
        loger_screen(ht.end)


#update CNF(helm release) via yaml
#please consider change of yaml in repo
def update_via_yaml(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL, CHART_VALUES_URL,wait_health,auto,uider):

    #check of CNF(helm release) before update
    #if is health check state good than continue, if no add error to log
    before_check = pod_health_check(NAMESPACE, NAME_HELM_DEP, wait_health)
    if before_check == True :
        loger('inf',lt.ht_bf,uider)
        loger_screen(lt.ht_bf)
        #execution of command
        #replace relevant {values} in template command_lists and execute command
        update_via_yaml_command=commands[5]
        update_via_yaml_command = update_via_yaml_command.replace('{NAMESPACE}', NAMESPACE)
        update_via_yaml_command = update_via_yaml_command.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
        update_via_yaml_command = update_via_yaml_command.replace('{CHART_NAME_URL}', CHART_NAME_URL)
        update_via_yaml_command = update_via_yaml_command.replace('{CHART_VALUES_URL}', CHART_VALUES_URL)
       
          
        loger('',lt.imp+update_via_yaml_command, uider)
        loger_screen(lt.oe)
        update_via_yaml_command_check = exec_command(update_via_yaml_command)
        loger_screen(lt.oe_d)

        #check if was execution of command True, if yes do health check
        #if no add error to log
        if update_via_yaml_command_check == True:
            #check of CNF(helm release) after update
            after_health_check = pod_health_check(NAMESPACE, NAME_HELM_DEP, wait_health)
            #check if is autorollback set to False
            #if yes add error log
            #if no delete CNF
            if after_health_check == True:
                loger('inf',lt.ht_af,uider)
                loger_screen(lt.ht_af)
            else:
                loger('err',lt.ht_af_err,uider)
                loger('inf',lt.rl_in+str(auto),uider)
                loger_screen(lt.ht_af_err_rl +str(auto))
                if auto == False:
                  loger('war',lt.pod,uider)
                  loger_screen(lt.pod)
                else:
                  loger('deb',lt.rol,uider)
                  rollback_revision_update(commands,NAMESPACE,NAME_HELM_DEP,1,wait_health,uider)
            # check history of revisions
            update_upgrade_history_check(commands, NAMESPACE, NAME_HELM_DEP)
        else:
            loger('err',lt.imp++update_via_yaml_command_check,uider)
            loger('war',lt.check,uider)
            loger_screen(update_via_yaml_command_check)
    else:
        loger('err',lt.ht_bf_err,uider)
        loger('war',lt.pod,uider)
        loger_screen(lt.ht_end)


#upgrade CNF(helm release) via change in chart version
def upgrade_chart_version(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL, CHART_VALUES_URL,wait_health,auto,uider):
    #check of CNF(helm release) before upgrade
    #if is health check state good than continue, if no add error to log
    before_check = pod_health_check(NAMESPACE, NAME_HELM_DEP, wait_health)
    if before_check == True :
        loger('info',lt.ht_bf,uider)
        loger_screen(lt.ht_bf)
        # execution of command
        # replace relevant {values} in template command_lists and execute command
        upgrade_CNF_command = commands[6]
        upgrade_CNF_command = upgrade_CNF_command.replace('{NAMESPACE}', NAMESPACE)
        upgrade_CNF_command = upgrade_CNF_command.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
        upgrade_CNF_command = upgrade_CNF_command.replace('{CHART_NAME_URL}', CHART_NAME_URL)
        upgrade_CNF_command = upgrade_CNF_command.replace('{CHART_VALUES_URL}', CHART_VALUES_URL)
        loger('deb',lt.imp+upgrade_CNF_command, uider)
        loger_screen(lt.oe)
        upgrade_chart_check = exec_command(upgrade_CNF_command)
        loger_screen(lt.oe_d)
        
        #check if was execution of command True, if yes do health check
        #if no add error to log
        if upgrade_chart_check == True:
            # check of CNF(helm release) after upgrade
            after_health_check = pod_health_check(NAMESPACE, NAME_HELM_DEP, wait_health)
            if after_health_check == True:
                loger('inf',lt.ht_af,uider)
                loger_screen(lt.hf_af)
            else:
                loger('err',lt.ht_af_err,uider)
                loger('inf',lt.rl_in+str(auto),uider)
                loger_screen(lt.ht_af_err_rl +str(auto))
                #check if is autorollback set to False
                #if yes add error log
                #if no delete CNF
                if auto == False:
                  loger('war',lt.pod,uider)
                  loger_screen(lt.pod)
                else:
                  loger('deb',lt.rol,uider)
                  rollback_revision_update(commands,NAMESPACE,NAME_HELM_DEP,1,wait_health,uider) 
            # check history of revisions
            update_upgrade_history_check(commands, NAMESPACE, NAME_HELM_DEP)
        else:
            loger('err',lt.imp+upgrade_chart_check,uider)
            loger('war',lt.check,uider)
            loger_screen(upgrade_chart_check)
    else:
       loger('err',lt.ht_bf_err,uider)
       loger('war',lt.pod,uider)
       loger_screen(lt.ht_end)

#rolback CNF(helm release)
def rollback_revision_CNF(commands,NAMESPACE,NAME_HELM_DEP,OLD_HELM_REVISION_BACK,wait_health,uider):

    #check of CNF(helm release) before rollback
    #if is health check state good than continue, if no add error to log
    before_check = pod_health_check(NAMESPACE, NAME_HELM_DEP, wait_health)
    if before_check == True:
        loger('inf',lt.ht_bf,uider)
        loger_screen(lt.ht_bf)
        # get value of last revision
        last_rev=commands[9]
        last_rev = last_rev.replace('{NAMESPACE}', NAMESPACE)
        last_rev = last_rev.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
        last_rev_exec=exec_command_special(last_rev)
        # create value for revision on which we want to return
        new_rev=(int(last_rev_exec)-int(OLD_HELM_REVISION_BACK))
        
        #condition on which rollback isn't possible
        #we can not rollback on revision which doesn't exist or revision more then 10 in return (10 is default value in helm)
        if (int(last_rev_exec) < new_rev) or (int(OLD_HELM_REVISION_BACK) >= 10):
            loger('err','Revision back is not possible ',uider)
            loger('war',lt.check,uider)
            loger_screen('Revision back is not possible. Please check input parameters')

        else:
            # execution of command
            # replace relevant {values} in template command_lists and execute command
            rollback_revision_CNF_command = commands[7]
            rollback_revision_CNF_command = rollback_revision_CNF_command.replace('{NAMESPACE}', NAMESPACE)
            rollback_revision_CNF_command = rollback_revision_CNF_command.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
            rollback_revision_CNF_command = rollback_revision_CNF_command.replace('{OLD_HELM_REVISION}', str(new_rev))
            loger('deb',lt.imp+rollback_revision_CNF_command, uider)
            loger_screen(lt.oe)
            rollbac_check = exec_command(rollback_revision_CNF_command)
            loger_screen(lt.oe_d)

            #check if was execution of command True, if yes do health check
            #if no add error to log
            if rollbac_check == True:
                after_health_check = pod_health_check(NAMESPACE, NAME_HELM_DEP, wait_health)
                if after_health_check == True:
                    loger('inf',lt.ht_af,uider)
                    loger_screen(lt.ht_af)                    
                else:
                    loger('err',lt.ht_af_err,uider)
                    loger('war',lt.pod,uider)
                    loger_screen('Error After operation health check is not good. Please check logs')
                    #loger('err','Implemantation of command: '+rollback_check,uider)
                    #loger('war','Please check input parameters',uider)

                # check history of revisions
                update_upgrade_history_check(commands, NAMESPACE, NAME_HELM_DEP)
            else:
                loger('err',lt.imp+rollbac_check,uider)
                loger('war',lt.check,uider)
                loger_screen(rollbac_check)

    else:
        loger('err',ls.ht_bf_err,uider)
        loger('war',lt.pod,uider)
        loger_screen(lt.ht_end)

#rolback CNF(helm release)
def rollback_revision_update(commands,NAMESPACE,NAME_HELM_DEP,OLD_HELM_REVISION_BACK,wait_health,uider):

    #check of CNF(helm release) before rollback
    #if is health check state good than continue, if no add error to log

    last_rev=commands[9]
    last_rev = last_rev.replace('{NAMESPACE}', NAMESPACE)
    last_rev = last_rev.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
    last_rev_exec=exec_command_special(last_rev)
    # create value for revision on which we want to return
    new_rev=(int(last_rev_exec)-int(OLD_HELM_REVISION_BACK))
        
    # execution of command
    # replace relevant {values} in template command_lists and execute command
    rollback_revision_CNF_command = commands[7]
    rollback_revision_CNF_command = rollback_revision_CNF_command.replace('{NAMESPACE}', NAMESPACE)
    rollback_revision_CNF_command = rollback_revision_CNF_command.replace('{NAME_HELM_DEP}', NAME_HELM_DEP)
    rollback_revision_CNF_command = rollback_revision_CNF_command.replace('{OLD_HELM_REVISION}', str(new_rev))
    loger('deb',lt.imp+rollback_revision_CNF_command, uider)
    rollbac_check = exec_command(rollback_revision_CNF_command)

    #check if was execution of command True, if yes do health check
    #if no add error to log
    if rollbac_check == True:
       after_health_check = pod_health_check(NAMESPACE, NAME_HELM_DEP, wait_health)
       if after_health_check == True:
          loger('inf',lt.hf,uider)
          loger_screen(lt.hf)
       else:
          loger('err',lt.ht_af_err,uider)
          loger('war',lt.ht_pod,uider)
          loger_screen(lt.ht_af_err)


          # check history of revisions
          update_upgrade_history_check(commands, NAMESPACE, NAME_HELM_DEP)
    else:
      loger('err',lt.imp+rollbac_check,uider)
      loger('war',lt.check,uider)
      loger_screen(rollbac_check)
 

