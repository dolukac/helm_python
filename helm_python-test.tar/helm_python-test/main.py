from time import sleep
import csv
import uuid
import yaml
import json
import re
from conf.log import loger,loger_screen
from conf import loging_text as lt
from conf import settings
from operation.cleaner import delete_namespace, delete_CNF
from operation.checker import cluster_health_check , get_namespaces, pod_health_check,listToString2,actual_date_time,actual_time
from operation.commands import exec_command,exec_command_need
from operation.create_namespace_CNF import create_namespace, instanciate_CNF
from operation.update_upgrade_CNF import update_via_cli, update_via_yaml, upgrade_chart_version, rollback_revision_CNF

start=actual_date_time()
#load template for commands
with open(settings.comander) as file:
    lines = file.readlines()
    commands = [line.rstrip() for line in lines]

#load input yaml
with open(settings.input_operation,'r') as file:
   configuration=yaml.safe_load(file)

#convert input yaml to json file
with open(settings.input_operation_json,'w') as json_file:
   json.dump(configuration,json_file)

#load json file as dictionary
with open(settings.input_operation_json,'r') as file:
   data=json.load(file)


if __name__ == "__main__":

    #load each dictionary from yaml file (yaml>json>dictionary)
    #generate uuid(identificator for log)
    #check if is cluster in good health if no then stop execute script
    #check if is key operation equal some operation
    #if is value one from operation perform this operation
    #if no just add information to log file
    #loger('debb','Input parameters: ','ff')
    
    loger('deb','',lt.start)
    for line in data:
       #generate uuid
       uider=uuid.uuid4()
       #check if is cluster in good health, if yes contintue if no, end script
       cluster_health_check(commands[0],uider)
       #create log for input parameters with print input operation
       loger_screen(lt.json)
       print(json.dumps(line,indent=4))

       log_line=list(line.items())
       log_line_str=','.join("%s:%s " %tup for tup in log_line)
       loger('deb',lt.inp+log_line_str,uider)
       
       #check if is key operation equal some operation and check if needed parameters exist
       if ('operation','create namespace') in line.items() and 'namespace' in line and 'timer' in line:
          loger('deb',lt.nam,uider)
          #operation=line.get('operation')
          #working_on(operation,uider)
          #loger('deb','Working on namespace creation',uider)
          #check if parameters which are needed for operation have some value
          #if no add error
          if line['namespace'] and line['timer']:
            #add value/values from line to parameters for function
            NAMESPACE=line.get('namespace')
            waith_health=line.get('timer')
            #execute operation
            create_namespace(commands,NAMESPACE,waith_health,uider)
          else:  
            loger('err',lt.nam_err,uider)
            loger_screen(lt.err+lt.name_err)
       
       #rest operations have same logic
       elif ('operation','delete namespace') in line.items() and all (k in line for k in ("namespace","timer")):
          loger('deb',lt.nam_del,uider)
          if line['namespace'] and line['timer']:
            NAMESPACE=line.get('namespace')
            wait_health=line.get('timer')
            delete_namespace(NAMESPACE,wait_health,uider) 
           
          else:
            loger('err',lt.nam_del_err,uider)
            loger_screen(lt.err+lt.nam_del)


       elif ('operation','instanciate CNF') in line.items() and all (k in line for k in ("namespace","cnf_name","chart_url","value_url","timer","autorollback")) :
          loger('deb',lt.ins,uider)
          if line['namespace'] and line['cnf_name'] and line['chart_url'] and line['value_url'] and line['timer'] and (line['autorollback']== True or line['autorollback']==False):
            NAMESPACE=line.get('namespace')
            NAME_HELM_DEP=line.get('cnf_name')
            CHART_NAME_URL=line.get('chart_url')
            CHART_VALUES_URL=line.get('value_url')
            wait_health=line.get('timer')
            auto=line.get('autorollback')
            instanciate_CNF(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL,CHART_VALUES_URL,wait_health,auto,uider)
          else:
            loger('err',lt.ins_err,uider)
            loger_screen(lt.err+lt.ins_err)
        
       elif ('operation','update via yaml') in line.items() and all (k in line for k in ("namespace","cnf_name","chart_url","value_url","timer","autorollback")):
          loger('deb',lt.yaml,uider)
          if line['namespace'] and line['cnf_name'] and line['chart_url'] and line['timer'] and line['value_url'] and (line['autorollback']== True or line['autorollback']==False):
            NAMESPACE=line.get('namespace')
            NAME_HELM_DEP=line.get('cnf_name')
            CHART_NAME_URL=line.get('chart_url')
            CHART_VALUES_URL=line.get('value_url')
            auto=line.get('autorollback')
            wait_health=line.get('timer')
           
            update_via_yaml(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL,CHART_VALUES_URL,wait_health,auto,uider) 
          else:
            loger('err',lt.yaml_err,uider)
            loger_screen(lt.err+lt.yaml)
       elif ('operation','update via CLI') in line.items() and all (k in line for k in ("namespace","cnf_name","chart_url","timer","autorollback","set")):
          loger('deb',lt.cli,uider)
          if line['namespace'] and line['cnf_name'] and line['chart_url'] and line['timer'] and line['set'] and (line['autorollback']== True or line['autorollback']==False):
            NAMESPACE=line.get('namespace')
            NAME_HELM_DEP=line.get('cnf_name')
            CHART_NAME_URL=line.get('chart_url')
            auto=line.get('autorollback')
            wait_health=line.get('timer')
            sets= line.get('set')
            s=""
            for i in sets:
                s+="--set "+str(i)+ ","
            SETS=re.sub(","," ",s)
           
            update_via_cli(commands, NAMESPACE, NAME_HELM_DEP, CHART_NAME_URL, SETS,wait_health,auto,uider)
          else:
            loger('err',lt.cli_err,uider)
            loger_screen(lt.err+lt.cli_err)
       elif ('operation','update chart') in line.items() and all (k in line for k in ("namespace","cnf_name","chart_url","value_url","timer","autorollback")):
          loger('deb',lt.upch,uider)
          if line['namespace'] and line['cnf_name'] and line['chart_url'] and line['value_url'] and line['timer'] and (line['autorollback']== True or line['autorollback']==False):

            NAMESPACE=line.get('namespace')
            NAME_HELM_DEP=line.get('cnf_name')
            CHART_NAME_URL_NEW_CHART=line.get('chart_url')
            CHART_VALUES_URL=line.get('value_url')
            auto=line.get('autorollback')
            wait_health=line.get('timer')
            upgrade_chart_version(commands,NAMESPACE,NAME_HELM_DEP,CHART_NAME_URL_NEW_CHART,CHART_VALUES_URL,wait_health,auto,uider)  
          else:
            loger('err',lt.upch_err,uider)
            loger_screen(lt.err+lt.upch_err)

       elif ('operation','rollback CNF') in line.items() and all (k in line for k in ("namespace","cnf_name","rolback_back_version","timer")):
          loger('deb',lt.rol,uider)
          if line['namespace'] and line['cnf_name'] and line['rolback_back_version'] and line['timer']:

            NAMESPACE=line.get('namespace')
            NAME_HELM_DEP=line.get('cnf_name')
            wait_health=line.get('timer')
            OLD_HELM_REVISION_BACK=line.get('rolback_back_version')
            rollback_revision_CNF(commands,NAMESPACE,NAME_HELM_DEP,OLD_HELM_REVISION_BACK,wait_health,uider)          
          else:
            loger('err',lt.roll_err,uider)
            logger_screen(lt.err+lt.roll_err)

       elif ('operation','delete CNF') in line.items() and all (k in line for k in ("namespace","cnf_name","timer")):
          loger('deb',lt.dele,uider)
          if line['namespace'] and line['cnf_name'] and line['timer']:
            NAMESPACE=line.get('namespace')
            NAME_HELM_DEP=line.get('cnf_name')
            wait_health=line.get('timer')
            delete_CNF(commands,NAMESPACE,NAME_HELM_DEP,wait_health,uider)
              
          else:
            loger('err',lt.dele_err,uider)
            loger_screen(lt.err+lt.dele_err)

       else:
          loger('err',lt.inp_err,uider)
          loger_screen(lt.err+lt.inp_err)
          #loger('err','Input parameters do not met condidion for any operation. Please check operation name or values',uider)
    loger('deb','',lt.end)
